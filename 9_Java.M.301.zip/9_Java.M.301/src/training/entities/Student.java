package training.entities;

import java.util.Scanner;

public class Student extends Person {

	String studentId;
	double theory;
	double practice;
	public Student(String fullname, String gender, String birthdate, String phonenumber, String email
			, String studentId, double theory, double practice) {
		super(fullname, gender, birthdate, phonenumber, email);
		this.studentId = studentId;
		this.theory = theory;
		this.practice = practice;
		// TODO Auto-generated constructor stub
	}	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public double calculateFinalMark() {
		return (theory+practice)/2.0;
	}
	public void Input(Scanner sc) {
		super.Input(sc);
		System.out.print("Input student ID: ");
		studentId = sc.nextLine();
		System.out.print("Input theory mark: ");
		theory = sc.nextDouble();
		System.out.print("Input practice mark: ");
		practice = sc.nextDouble();
	}
}
