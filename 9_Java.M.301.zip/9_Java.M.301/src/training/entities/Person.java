package training.entities;

import java.util.Scanner;

public abstract class Person {

	String fullname;
	String gender;
	String birthdate;
	String phonenumber;
	String email;
	
	public Person()
	{
		
	}
	public Person(String fullname, String gender, String birthdate, String phonenumber, String email) {
		super();
		this.fullname = fullname;
		this.gender = gender;
		this.birthdate = birthdate;
		this.phonenumber = phonenumber;
		this.email = email;
	}
	
	public void Input(Scanner sc) {

		System.out.print("Input name: "); 
		fullname =  sc.nextLine();
		sc.nextLine();
		System.out.print("Input gender: "); 
		gender = sc.nextLine();
		System.out.print("Input birthdate: "); 
		birthdate = sc.nextLine();
		System.out.print("Input phone number: "); 
		phonenumber = sc.nextLine();
		System.out.print("Input email: "); 
		email = sc.nextLine();
		
	}
	
}
