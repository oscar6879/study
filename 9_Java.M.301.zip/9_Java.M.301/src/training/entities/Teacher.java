package training.entities;

import java.util.Scanner;

public class Teacher extends Person{
	
	double basicSalary;
	double subsidy;
	public Teacher(String fullname, String gender, String birthdate, String phonenumber, String email
			, double basicSalary, double subsidy) {
		super(fullname, gender, birthdate, phonenumber, email);
		this.basicSalary = basicSalary;
		this.subsidy = subsidy;
		// TODO Auto-generated constructor stub
	}	
	
	public Teacher() {
		// TODO Auto-generated constructor stub
	}

	public double calculateSalary() {
		return basicSalary + subsidy;
	}
	public void Input(Scanner sc) {
		super.Input(sc);
		System.out.print("Input basic salary: ");
		basicSalary = sc.nextDouble();
		System.out.print("Input subsidy: ");
		subsidy = sc.nextDouble();
	}
}
