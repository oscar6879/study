package training.main;

import java.util.Scanner;

import training.entities.*;

public class PersonManage {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		Person[] person = new Person[2];
		
		for (int i=0; i<2; i++)
		{
			System.out.println("Person "+(i+1)+": ");
			System.out.print("1.Student?    2.Teacher? :");
			int per = sc.nextInt();
			if (per==1) {
				Student stu = new Student();
				stu.Input(sc);
				person[i]=stu;
			}
			else {
				Teacher tea = new Teacher();
				tea.Input(sc);
				person[i]=tea;
			}
			
		}
	}
	
}
