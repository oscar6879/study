package training.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
	private static final String VALID_EMAIL_REGEX = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]"
						+ "+\\.[a-zA-Z]{2,6}$";
	public static boolean isEmail(String emailAddress) {
			Pattern pattern = Pattern.compile(VALID_EMAIL_REGEX);
			Matcher matcher = pattern.matcher(emailAddress);
			return matcher.matches();
		}
	
	public static boolean validate(String date) {
        SimpleDateFormat val = new SimpleDateFormat("dd/MM/yyyy");
       
        val.setLenient(false);
        try {
            val.parse(date);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }
}
