package exercise3;

import java.util.Scanner;

public class FrequentNumber {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Input len:");
		int len = scanner.nextInt();

		int[] arr = new int[len];

		int flag = 0;
		do {
			System.out.print("Arr[" + flag + "]= ");
			arr[flag] = scanner.nextInt();
			flag ++;
			scanner.nextLine();
			System.out.println("Do you want to continue?");
			String cont = scanner.nextLine();
			if(cont.equals("N") || cont.equals("n")) {
				break;
			}
		} while (flag < len);
		
		System.out.print("Input value: ");
		int value = scanner.nextInt();
		int count = 0;
		
		for (int i = 0; i < arr.length; i++) {
			if(value == arr[i]) {
				count++;
			}
		}
		
		System.out.println("Amount of frequence: " + count);
		
		System.out.print("Index: ");
		for (int i = 0; i < arr.length; i++) {
			if(value == arr[i]) {
				
				System.out.print(i+ " ");
			}
		}
		scanner.close();
	}
}
