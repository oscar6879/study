package exercise4;

import java.util.Scanner;
public class ArrayReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.print("Input length of arrays: ");
		int length = scanner.nextInt();

		System.out.println("Input Array:");
		String[] arr = new String[length];
		scanner.nextLine();
		for (int i = 0; i < length; i++) {
			System.out.print("Phan tu thu " + i + ":");
			arr[i] = scanner.nextLine();
		}
		System.out.print("Original Array: ");
		for (int i = 0; i < arr.length; i++) {
			if(i == (arr.length- 1)) {
				System.out.print(arr[i]);
			}else {
				System.out.print(arr[i]+ ", ");
			}
		}
		System.out.println();
		System.out.print("Reversed Array: ");
		for (int j = (arr.length-1) ; j>=0;j--) {
			if( j == 0) {
				System.out.print(arr[j]);
			}else System.out.print(arr[j]+ ", ");
			
		}
		scanner.close();
	}

}
