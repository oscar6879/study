package exercise2;

import java.util.Scanner;

public class ArrayContains {

	public static void main(String[] args) {
		try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("Input length of arrays: ");
			int length = scanner.nextInt();

			System.out.println("Input Array:");
			String[] arr = new String[length];
			scanner.nextLine();
			for (int i = 0; i < length; i++) {
				System.out.print("Phan tu thu " + i + ":");
				arr[i] = scanner.nextLine();
			}
			System.out.println("Input sValue:");
			String sValue = scanner.nextLine();
			boolean check = false;
			for (int i = 0; i < arr.length; i++) {
				if(arr[i].equals(sValue)) {
					System.out.println("Check '" + sValue +"' in Array: Contained!");
					check = true;
					break;
				}
			}
			if(check == false) {
				System.out.println("Check '" + sValue +"' in Array: No Contain!");
			}

		}
	}

}
