package exercise1;

public class SumAverageRunningInt {
	public static void main(String[] args) {
		int lowerbound = 1;
		int upperbound = 100;
		int sum = 0 ;
		float Average;
		for (int i = lowerbound; i<= upperbound; i++) {
			sum += i;
		}
		Average = sum/(upperbound -lowerbound + 1);
		System.out.printf("Average of all 100 first numbers: %.1f",Average);
	}
	
}
