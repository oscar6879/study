CREATE DATABASE movietheaterdb2;
GO

IF NOT EXISTS ( SELECT * FROM sys.schemas WHERE name = N'MovieTheater' )
EXEC('CREATE SCHEMA [MovieTheater]');


