package training.dao;

public class MovieTypeDaoImpl extends EntityDao<Object> {

}
