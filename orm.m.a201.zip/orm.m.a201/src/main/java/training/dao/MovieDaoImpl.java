package training.dao;

public class MovieDaoImpl extends EntityDao<Object> {


}
