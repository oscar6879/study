package training.dao;

public class TypeDaoImpl extends EntityDao<Object> {

}
