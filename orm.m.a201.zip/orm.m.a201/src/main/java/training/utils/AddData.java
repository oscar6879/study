package training.utils;

import java.time.LocalDate;

import training.dao.EntityDao;
import training.entities.Movie;
import training.entities.MovieType;
import training.entities.MultiId;
import training.entities.Type;

public class AddData {
	public static void addData() {
		EntityDao<Object> entityDao = new EntityDao<>();
		
		Type type1 = new Type("Type 1", "Description 1");
		Type type2 = new Type("Type 2", "Description 2");
		Type type3 = new Type("Type 3", "Description 3");

		entityDao.save(type1);
		entityDao.save(type2);
		entityDao.save(type3);

		Movie movie1 = new Movie("Movie00001", "Actor 1", "content 1", "Director 1", 120.01, LocalDate.of(1999, 1, 1),
				LocalDate.of(2000, 1, 1), "Company 1", "Version 1", "Name Eng 1", "Name VN 1", "Large Image 1",
				"Small Image 1");

		Movie movie2 = new Movie("Movie00002", "Actor 2", "content 2", "Director 2", 120.02, LocalDate.of(1999, 1, 2),
				LocalDate.of(2000, 1, 2), "Company 2", "Version 2", "Name Eng 2", "Name VN 2", "Large Image 2",
				"Small Image 2");

		Movie movie3 = new Movie("Movie00003", "Actor 3", "content 3", "Director 3", 120.03, LocalDate.of(1999, 1, 3),
				LocalDate.of(2000, 1, 3), "Company 3", "Version 3", "Name Eng 3", "Name VN 3", "Large Image 3",
				"Small Image 3");

		Movie movie4 = new Movie("Movie00004", "Actor 4", "content 4", "Director 4", 120.04, LocalDate.of(1999, 1, 4),
				LocalDate.of(2000, 1, 4), "Company 4", "Version 4", "Name Eng 4", "Name VN 4", "Large Image 4",
				"Small Image 4");

		Movie movie5 = new Movie("Movie00005", "Actor 5", "content 5", "Director 5", 120.05, LocalDate.of(1999, 1, 5),
				LocalDate.of(2000, 1, 5), "Company 5", "Version 5", "Name Eng 5", "Name VN 5", "Large Image 5",
				"Small Image 5");

		Movie movie6 = new Movie("Movie00006", "Actor 6", "content 6", "Director 6", 120.06, LocalDate.of(1999, 1, 6),
				LocalDate.of(2000, 1, 6), "Company 6", "Version 6", "Name Eng 6", "Name VN 6", "Large Image 6",
				"Small Image 6");

		entityDao.save(movie1);
		entityDao.save(movie2);
		entityDao.save(movie3);
		entityDao.save(movie4);
		entityDao.save(movie5);
		entityDao.save(movie6);

		MultiId multiId1 = new MultiId(1, "Movie00001");
		MultiId multiId2 = new MultiId(2, "Movie00002");
		MultiId multiId3 = new MultiId(3, "Movie00003");

		MovieType movieType1 = new MovieType(multiId1, "Description 1");
		MovieType movieType2 = new MovieType(multiId2, "Description 2");
		MovieType movieType3 = new MovieType(multiId3, "Description 3");

		entityDao.save(movieType1);
		entityDao.save(movieType2);
		entityDao.save(movieType3);
	}
}
