package training.utils;

import java.util.Scanner;

import training.dao.EntityDao;
import training.entities.MovieType;
import training.entities.Type;

public class Menu {
	static Scanner sc = new Scanner(System.in);

	// Exit function
	public static void exit() {
		for (int i = 0; i < 60; i++)
			System.out.println();
		System.out.println("Ban da thoat khoi chuong trinh. Cam on!");
	}

	// Main menu
	public static void MainMenu() {
		EntityDao<Object> entityDao = new EntityDao<>();

		System.out.println("----//----//----//----//----//----//----//----//----");
		System.out.println("1. View all Type");
		System.out.println("2. View all Movie");
		System.out.println("3. View all Movie Type");
		System.out.println("4. Get Type by id");
		System.out.println("5. Get Movie Type by id");
		System.out.println("6. Exit");
		System.out.println("Nhan phim 6 neu muon thoat chuong trinh");
		System.out.println("------------------------------------------");
		System.out.println("Lua chon cua ban la: ");
		int choice0 = sc.nextInt();
		switch (choice0) {
		case 1:
			entityDao.print(entityDao.getAll("Type"));
			MainMenu();
			break;
		case 2:
			entityDao.print(entityDao.getAll("Movie"));
			MainMenu();
			break;
		case 3:
			entityDao.print(entityDao.getAll("MovieType"));
			MainMenu();
			break;
		case 4:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new Type(),sc.nextInt()));
			MainMenu();
			break;
		case 5:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new MovieType(),sc.nextInt()));
			MainMenu();
			break;
		case 6:
			exit();
			break;
		default:
			System.out.println("Ban da nhap sai. Xin moi nhap lai lua chon");
			MainMenu();
			break;
		}
	}

	// Main menu
	public static void SubMenu1() {
		System.out.println("----//----//----//----//----//----//----//----//----");
		System.out.println("Nhap lua chon chuong trinh:");
		System.out.println("Nhan phim 1 ...");
		System.out.println("Nhan phim 2 ...");
		System.out.println("Nhan phim 3 de quay lai menu truoc");
		System.out.println("Nhan phim 4 neu muon thoat chuong trinh");
		System.out.println("------------------------------------------");
		System.out.println("Lua chon cua ban la: ");
		int choice0 = sc.nextInt();
		switch (choice0) {
		case 1:
			break;
		case 2:
			break;
		case 3:
			MainMenu();
			break;
		case 4:
			exit();
			break;
		default:
			System.out.println("Ban da nhap sai. Xin moi nhap lai lua chon");
			SubMenu1();
			break;
		}
	}

}
