package training.main;

import training.utils.AddData;
import training.utils.Menu;

public class Main {
	public static void main(String[] args) {
		AddData.addData();
		Menu.MainMenu();
	}

}
