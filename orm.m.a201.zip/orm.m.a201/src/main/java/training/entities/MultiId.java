package training.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MultiId implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Column(name = "TYPE_ID", unique = true)
	private int typeIdMT;
	
	@Column(name = "MOVIE_ID", columnDefinition = "varchar(10)", unique = true)
	private String movieIdMT;

	/**
	 * @return the typeIdMT
	 */
	public int getTypeIdMT() {
		return typeIdMT;
	}

	/**
	 * @param typeIdMT the typeIdMT to set
	 */
	public void setTypeIdMT(int typeIdMT) {
		this.typeIdMT = typeIdMT;
	}

	/**
	 * @return the movieIdMT
	 */
	public String getMovieIdMT() {
		return movieIdMT;
	}

	/**
	 * @param movieIdMT the movieIdMT to set
	 */
	public void setMovieIdMT(String movieIdMT) {
		this.movieIdMT = movieIdMT;
	}


	public MultiId(int typeIdMT, String movieIdMT) {
		super();
		this.typeIdMT = typeIdMT;
		this.movieIdMT = movieIdMT;
	}

	public MultiId() {
		super();
	}

	@Override
	public String toString() {
		return "MultiId [typeIdMT=" + typeIdMT + ", movieIdMT=" + movieIdMT + "]";
	}
	
	

}
