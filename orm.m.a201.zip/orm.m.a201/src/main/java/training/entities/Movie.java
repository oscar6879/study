package training.entities;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "MOVIE", schema = "MovieTheater")
public class Movie {

	@Id
	@Column(name = "MOVIE_ID", columnDefinition = "varchar(10)", unique = true)
	private String movieId;

	@Column(name = "ACTOR")
	private String actor;

	@Column(name = "CONTENT", columnDefinition = "varchar(1000)")
	private String content;

	@Column(name = "DIRECTOR")
	private String director;

	@Column(name = "DURATION", columnDefinition = "decimal(5,2)")
	private double duration;

	@Column(name = "FROM_DATE")
	private LocalDate fromDate;

	@Column(name = "TO_DATE")
	private LocalDate toDate;

	@Column(name = "MOVIE_PRODUCTION_COMPANY")
	private String movieProCompany;

	@Column(name = "VERSION")
	private String version;

	@Column(name = "MOVIE_NAME_ENG", unique = true)
	private String movieNameEng;

	@Column(name = "MOVIE_NAME_VN", unique = true)
	private String movieNameVn;

	@Column(name = "LARGE_IMAGE")
	private String largeImage;

	@Column(name = "SMALL_IMAGE")
	private String smallImage;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "movie")
	private Set<MovieType> movieType2 = new HashSet<>();

	/**
	 * @return the movieId
	 */
	public String getMovieId() {
		return movieId;
	}

	/**
	 * @param movieId the movieId to set
	 */
	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}

	/**
	 * @return the actor
	 */
	public String getActor() {
		return actor;
	}

	/**
	 * @param actor the actor to set
	 */
	public void setActor(String actor) {
		this.actor = actor;
	}

	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/**
	 * @return the director
	 */
	public String getDirector() {
		return director;
	}

	/**
	 * @param director the director to set
	 */
	public void setDirector(String director) {
		this.director = director;
	}

	/**
	 * @return the duration
	 */
	public double getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(float duration) {
		this.duration = duration;
	}

	/**
	 * @return the fromDate
	 */
	public LocalDate getFromDate() {
		return fromDate;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @return the toDate
	 */
	public LocalDate getToDate() {
		return toDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the movieProCompany
	 */
	public String getMovieProCompany() {
		return movieProCompany;
	}

	/**
	 * @param movieProCompany the movieProCompany to set
	 */
	public void setMovieProCompany(String movieProCompany) {
		this.movieProCompany = movieProCompany;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return the movieNameEng
	 */
	public String getMovieNameEng() {
		return movieNameEng;
	}

	/**
	 * @param movieNameEng the movieNameEng to set
	 */
	public void setMovieNameEng(String movieNameEng) {
		this.movieNameEng = movieNameEng;
	}

	/**
	 * @return the movieNameVn
	 */
	public String getMovieNameVn() {
		return movieNameVn;
	}

	/**
	 * @param movieNameVn the movieNameVn to set
	 */
	public void setMovieNameVn(String movieNameVn) {
		this.movieNameVn = movieNameVn;
	}

	/**
	 * @return the largeImage
	 */
	public String getLargeImage() {
		return largeImage;
	}

	/**
	 * @param largeImage the largeImage to set
	 */
	public void setLargeImage(String largeImage) {
		this.largeImage = largeImage;
	}

	/**
	 * @return the smallImage
	 */
	public String getSmallImage() {
		return smallImage;
	}

	/**
	 * @param smallImage the smallImage to set
	 */
	public void setSmallImage(String smallImage) {
		this.smallImage = smallImage;
	}

	/**
	 * @return the movieType2
	 */
	public Set<MovieType> getMovieType2() {
		return movieType2;
	}

	/**
	 * @param movieType2 the movieType2 to set
	 */
	public void setMovieType2(Set<MovieType> movieType2) {
		this.movieType2 = movieType2;
	}

	
	
	public Movie(String movieId, String actor, String content, String director, double duration, LocalDate fromDate,
			LocalDate toDate, String movieProCompany, String version, String movieNameEng, String movieNameVn,
			String largeImage, String smallImage) {
		super();
		this.movieId = movieId;
		this.actor = actor;
		this.content = content;
		this.director = director;
		this.duration = duration;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.movieProCompany = movieProCompany;
		this.version = version;
		this.movieNameEng = movieNameEng;
		this.movieNameVn = movieNameVn;
		this.largeImage = largeImage;
		this.smallImage = smallImage;
	}

	public Movie() {
		super();
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", actor=" + actor + ", content=" + content + ", director=" + director
				+ ", duration=" + duration + ", fromDate=" + fromDate + ", toDate=" + toDate + ", movieProCompany="
				+ movieProCompany + ", version=" + version + ", movieNameEng=" + movieNameEng + ", movieNameVn="
				+ movieNameVn + ", largeImage=" + largeImage + ", smallImage=" + smallImage + "]";
	}

	
}
