package training.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TYPE", schema = "MovieTheater")
public class Type {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TYPE_ID",unique = true)
	private int typeId;

	@Column(name = "TYPE_NAME", unique = true)
	private String typeName;

	@Column(name = "TYPE_DESCRIPTION")
	private String typeDesc;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "type")
	private Set<MovieType> movieType1 = new HashSet<>();

	/**
	 * @return the typeId
	 */
	public int getTypeId() {
		return typeId;
	}

	/**
	 * @param typeId the typeId to set
	 */
	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	/**
	 * @return the typeName
	 */
	public String getTypeName() {
		return typeName;
	}

	/**
	 * @param typeName the typeName to set
	 */
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	/**
	 * @return the typeDesc
	 */
	public String getTypeDesc() {
		return typeDesc;
	}

	/**
	 * @param typeDesc the typeDesc to set
	 */
	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}

	/**
	 * @return the movieType1
	 */
	public Set<MovieType> getMovieType1() {
		return movieType1;
	}

	/**
	 * @param movieType1 the movieType1 to set
	 */
	public void setMovieType1(Set<MovieType> movieType1) {
		this.movieType1 = movieType1;
	}

	public Type(String typeName, String typeDesc) {
		super();
		this.typeName = typeName;
		this.typeDesc = typeDesc;
	}

	public Type() {
		super();
	}

	@Override
	public String toString() {
		return "Type [typeId=" + typeId + ", typeName=" + typeName + ", typeDesc=" + typeDesc + "]";
	}
	
	

}
