package training.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MOVIE_TYPE", schema = "MovieTheater")
public class MovieType {

	@EmbeddedId
	private MultiId multiId;

	@Column(name = "MT_DESCRIPTION")
	private String mtDesc;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "TYPE_ID", referencedColumnName = "TYPE_ID", insertable = false, updatable = false)
	private Type type;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "MOVIE_ID", referencedColumnName = "MOVIE_ID", insertable = false, updatable = false)
	private Movie movie;

	/**
	 * @return the multiId
	 */
	public MultiId getMultiId() {
		return multiId;
	}

	/**
	 * @param multiId the multiId to set
	 */
	public void setMultiId(MultiId multiId) {
		this.multiId = multiId;
	}

	/**
	 * @return the mtDesc
	 */
	public String getMtDesc() {
		return mtDesc;
	}

	/**
	 * @param mtDesc the mtDesc to set
	 */
	public void setMtDesc(String mtDesc) {
		this.mtDesc = mtDesc;
	}

	/**
	 * @return the type
	 */
	public Type getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(Type type) {
		this.type = type;
	}

	/**
	 * @return the movie
	 */
	public Movie getMovie() {
		return movie;
	}

	/**
	 * @param movie the movie to set
	 */
	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public MovieType(MultiId multiId, String mtDesc) {
		super();
		this.multiId = multiId;
		this.mtDesc = mtDesc;
	}

	public MovieType() {
		super();
	}

	@Override
	public String toString() {
		return "MovieType [multiId=" + multiId + ", mtDesc=" + mtDesc + ", type=" + type + ", movie=" + movie + "]";
	}
	
	
	

}
