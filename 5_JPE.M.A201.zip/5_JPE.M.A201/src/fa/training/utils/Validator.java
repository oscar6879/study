package fa.training.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
	private static final String VALID_COURSE_CODE_REGEX = "^FW\\d{3}$";
	
	//Check course code is valid.
	public static boolean isCourseCode(String courseCode) {
		Pattern pattern = Pattern.compile(VALID_COURSE_CODE_REGEX);
		Matcher matcher = pattern.matcher(courseCode);
		return matcher.matches();
	}
	
	//Check status is valid.
	public static boolean isStatus(String status) {
		if(status.equalsIgnoreCase("active") || status.equalsIgnoreCase("in-active"))
			return true;
		return false;
	}
	
	//Check flag is valid.
		public static boolean isFlag(String flag) {
			if(flag.equalsIgnoreCase("optional") || flag.equalsIgnoreCase("mandatory")
					|| flag.equalsIgnoreCase("N/A"))
				return true;
			return false;
		}
}