package fa.training.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.entities.Course;

public class CourseManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Course> coursesArr = new ArrayList<Course>();
		Course course;
		
		//Create an array of 10 courses and input data from the keyboard.
		System.out.println("1. Create course:");
		for (int i = 0; i < 2; i++) {
			course = new Course();
			System.out.println("- Enter course[" + (i + 1) + "]: ");
			course.input();
			coursesArr.add(course);
		}
		
		System.out.println("List course:");
		for (Course courses : coursesArr) {
			System.out.println(courses);
		}
		
		//Search courses by one of the attributes
		System.out.println("2. Search courses by one of the attributes:");
		Scanner sc = new Scanner(System.in);
		String type = sc.nextLine();
		find(type, coursesArr);
		
		//Display all courses that flag is �mandatory�.
		System.out.println("3. Display all courses that flag is �mandatory�.");
		find("mandatory", coursesArr);
	}
	
	public static void find(String type, List<Course> data) {
		boolean check = false;
		for (Course course : data) {
			if(course.search(type)) {
				System.out.println(course);
				check = true;
			}
		}
		
		if(check == false) System.out.println("NONE!!!");
	}
	


}
