package fa.training.entities;

import java.util.Scanner;

import fa.training.utils.Validator;

public class Course {
	private String id;
	private String name;
	private double duration;
	private String status;
	private String flag;

	public Course() {
		super();
	}

	public Course(String id, String name, double duration, String status, String flag) {
		super();
		this.id = id;
		this.name = name;
		this.duration = duration;
		this.status = status;
		this.flag = flag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	@Override
	public String toString() {
		return "Student ["
				+ "id=" + id + ", " 
				+ "name=" + name + ", "
				+ "duration=" + duration + ", "
				+ "status=" + status + ", flag=" + flag + "]";
	}

	public void input() {
		Scanner scanner = new Scanner(System.in);
		boolean check;

		do {
			check = false;
			System.out.print("Enter course code (FW...):");
			try {
				id = scanner.nextLine();
				check = !Validator.isCourseCode(id);
			} catch (Exception exception) {
				check = true;
			}
		} while (check);

		System.out.print("Enter course name: ");
		name = scanner.nextLine();
		System.out.print("Enter course duration: ");
		duration = Double.parseDouble(scanner.nextLine());

		do {
			check = false;
			System.out.print("Enter course status: ");
			try {
				status = scanner.nextLine();
				check = !Validator.isStatus(status);
			} catch (Exception e) {
				check = true;
			}
		} while (check);

		do {
			check = false;
			System.out.print("Enter course flag: ");
			try {
				flag = scanner.nextLine();
				check = !Validator.isFlag(flag);
			} catch (Exception e) {
				check = true;
			}
		} while (check);

		// scanner.close();
	}

	public boolean search(String type) {
		if (type.equalsIgnoreCase(id) 
				|| type.equalsIgnoreCase(name) 
				|| type.equalsIgnoreCase(String.valueOf(duration))
				|| type.equalsIgnoreCase(status) 
				|| type.equalsIgnoreCase(flag))
			return true;
		return false;
	}
}
