package exercise;

/**
 * The class to calculate the sum, subtraction, multiplication, and division of
 * two integer numbers.
 * 
 * @author DieuNT1
 *
 */
public class Calculator {
  
  public int sum(int number1, int number2) {
    return (number1 + number2);
  }

  public int sub(int number1, int number2) {
    return (number1 - number2);
  }

  public int mul(int number1, int number2) {
    return (number1 * number2);
  }

  public int div(int number1, int number2) {
    return (number1 / number2);
  }
}
