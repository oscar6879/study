package exercise;

public class Child extends Parent implements MyInterface {

}
