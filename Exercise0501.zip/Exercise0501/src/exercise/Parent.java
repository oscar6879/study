package exercise;

public class Parent {

}
