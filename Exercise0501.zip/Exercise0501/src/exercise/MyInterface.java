package exercise;

public interface MyInterface {

}
