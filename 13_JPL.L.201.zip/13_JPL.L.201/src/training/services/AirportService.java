package training.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.entities.Airplane;
import fa.training.entities.Airport;
import fa.training.entities.Fixedwing;
import fa.training.entities.Helicopter;

public class AirportService {	
	static Scanner sc = new Scanner(System.in);	
	public List<Airport> creatAirport() {
		List<Airport> list = new ArrayList<Airport>();
		
		String key;
		do {
			Airport air = new Airport();
			air.inputAirport();
			list.add(air);
			System.out.print("Continue?  Y/N : ");
			key = sc.next();
			if(key.equals("N")||key.equals("n")) break;
		} while (true);	
		sc.close();
		return list;
	}
	
	
	
	public List<String> getListIdHelicopter(List<Airplane> listair) {
		
		List<String> list = new ArrayList<String>();
		for (Airplane air : listair) {
			if(air instanceof Helicopter) {
				list.add(((Helicopter)air).getID());
			}
		}							
		return list;
	}	
	
}
	
	

