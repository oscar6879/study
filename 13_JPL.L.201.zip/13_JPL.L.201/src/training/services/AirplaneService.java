package training.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.entities.Airplane;
import fa.training.entities.Fixedwing;
import fa.training.entities.Helicopter;

public class AirplaneService {
	static List<Airplane> list1 = new ArrayList<Airplane>();
	static Scanner sc = new Scanner(System.in);
	public static List<Airplane> createAirplane() {		
		List<Airplane> list = new ArrayList<Airplane>();
		int key;
		do {
			System.out.println("1. Fixed-wing airplane");
			System.out.println("2. Helicopter");
			System.out.println("0. Exit");
			System.out.print("Input airplane type: ");
			key = sc.nextInt();			
			switch (key) {
			case 1:
				Airplane fix = new Fixedwing();
				((Fixedwing)fix).input();
				list.add(fix);
				break;
			case 2:
				Airplane heli = new Helicopter();
				((Helicopter)heli).input();
				list.add(heli);
				break;			
			}
		} while (key != 0);
		sc.close();
		return list;
	}
	
	public static void displayAllAirplane(List<Airplane> listair) {
		for (Airplane air : listair) {
			System.out.println(air.toString());
		}
	}
	
	public void displayAllHelicopter(List<Airplane> listair) {
		for (Airplane air : listair) {
			if(air instanceof Helicopter) {
				System.out.println(((Helicopter)air).toString());;
			}
		}
	}
	
	public void displayAllFixedwing(List<Airplane> listair) {
		for (Airplane air : listair) {
			if(air instanceof Fixedwing) {
				System.out.println(((Fixedwing)air).toString());;
			}
		}
	}
	
	public void removeAirplane(List<Airplane> listair) {
		System.out.print("Input ID: ");
		String id = sc.next();
		listair.removeIf(air -> air.getID().equalsIgnoreCase(id));
	}
	
	public static void main(String[] args) {
		list1 = createAirplane();
		displayAllAirplane(list1);
	}
}
