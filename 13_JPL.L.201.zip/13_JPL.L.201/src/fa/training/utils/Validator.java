package fa.training.utils;


public class Validator {
	public boolean validID(String id) {
		return id.matches("^(FW)\\d{5}") || id.matches("^(AP)\\d{5}") || id.matches("^(RW)\\d{5}");
	}
	public boolean validModel(String model) {
		return model.length()<= 40;
	}
	public boolean validFixedWing(String type) {
		return type.matches("^(CAG)||(LGR)||(PRV)");
	}
	public boolean validWingsize(double size, double maximum) {
		return size <= maximum;
	}
	public boolean validMaxtakeoff(double takeoff, double empty_weight) {
		return takeoff <= 1.5 * empty_weight;
	}
}
