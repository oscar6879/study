package fa.training.utils;


public class test2  extends test{
	public static void main(String[] args) {
		
	}
	
}
