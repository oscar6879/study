package fa.training.utils;

public class test {
	public static void main(String[] args) {
		String a= "helo";
		StringBuffer a1 = new StringBuffer("helo");
		a1.reverse();
		//a.rev
		System.out.println(a1);
		
	}
		
}

