package fa.training.main;
public class AirplaneManagement {
	
}
