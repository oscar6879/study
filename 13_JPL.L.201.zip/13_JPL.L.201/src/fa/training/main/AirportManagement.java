package fa.training.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import fa.training.entities.Airplane;
import fa.training.entities.AirplaneCompare;
import fa.training.entities.Airport;
import fa.training.entities.Fixedwing;
import fa.training.entities.Helicopter;
import training.services.AirportService;

public class AirportManagement {
	static List<Airport> listAirport  = new ArrayList<Airport>();
	static List<Airplane> listAirplane  = new ArrayList<Airplane>();
	static Set<String> listOnAir  = new HashSet<String>();


	static AirportService as = new AirportService();
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		Airport air1 = new Airport("A1", "Da Nang Airport", 10, 100, 100, null, null);
		Airport air2 = new Airport("A2", "Ha Noi Airport", 20, 200, 200, null, null);
		Airport air3 = new Airport("A3", "Ho Chi Minh Airport", 30, 300, 300, null, null);
		listAirport.add(air1);listAirport.add(air2);listAirport.add(air3);

		Airplane a1 = new Helicopter("H1","Helicopter 1", 10,10,10,10);
		Airplane a2 = new Helicopter("H2","Helicopter 2", 20,20,20,20);
		Airplane a3 = new Helicopter("H3","Helicopter 3", 30,30,30,30);
		listAirplane.add(a1);listAirplane.add(a2);listAirplane.add(a3);

		Airplane a4 = new Fixedwing("F1", "Fixedwing 1", 40, 40, 40, 400, "vip1");
		Airplane a5 = new Fixedwing("F2", "Fixedwing 2", 50, 50, 50, 50, "vip1");
		Airplane a6 = new Fixedwing("F3", "Fixedwing 3", 60, 60, 60, 60, "vip1");
		listAirplane.add(a4);listAirplane.add(a5);listAirplane.add(a6);

		for (Airplane id : listAirplane) {
			listOnAir.add(id.getID());
		}	

		Collections.sort(listAirplane, new AirplaneCompare());
		
		for (Airplane string : listAirplane) {
			System.out.println(string.toString());
		}		
		
		int select;
		do {
			System.out.println("1. Add Helicopter to the Airport ");
			System.out.println("2. Add Fixedwing to the Airport ");
			System.out.println("3. Display all airplane in each Airport ");
			System.out.println("4. Remove airplane from Airport ");
			System.out.println("5. Display airplane on air ");
			System.out.println("6. Remove Airplane ");
			System.out.println("0. Exit ");
			System.out.print("Input function: ");			
			select = sc.nextInt();
			switch (select) {
			case 1:				
				addHelicopter();
				break;
			case 2:
				addFixedwing();
				break;
			case 3:
				displayAllAirplaneInEachAirport();
				break;
			case 4:
				removeAirplaneFromAirport();
				break;
			case 5:
				displayAirplaneOnAir();
				break;
			case 6:
				removeAirplane();;
				break;
			case 7:
				saveFile();
				break;
			
			default:
				break;
			}
		} while (select != 0);			


	}
	
	public static void saveFile() {
		File file = new File("D:\\Duydn11\\JPE\\eclipse_workspace\\JPL.L.A201(902)\\902.txt");
		
		FileWriter fw;
		try {
			fw = new FileWriter(file);
			fw.write("=========Air plane======"+"\n");
			for (Airplane air : listAirplane) {
				fw.write(air.toString()+"\n");
			}
			fw.write("=========Airport======"+"\n");
			for (Airport air : listAirport) {
				fw.write(air.toString()+"\n");
			}
			fw.close();	
		} catch (IOException e) {					
			e.printStackTrace();
		}						
	}
	

	private static void displayAllAirplaneInEachAirport() {
		for (Airport a : listAirport) {
			System.out.println(a.toString());
		}

	}

	public static void displayAirplaneOnAir() {		
		for (Airplane air : listAirplane) {
			if(listOnAir.contains(air.getID())) {
				System.out.println(air.toString());
			}
		}

	}

	public static void addHelicopter() {
		String listid = "";
		for (Airplane a : listAirplane) {
			if(a instanceof Helicopter) {
				listid += a.getID()+" ";
			}
		}
		System.out.println("List id heli: "+listid);

		List<String> listadd = new ArrayList<String>();
		while (true) {
			System.out.print("Input heli id: ");
			listadd.add(sc.next());
			System.out.print("Continue? Y/N :");
			if(sc.next().equals("n")) break;
		}		

		System.out.print("Input Airport ID to add Helicopter: ");
		String id = sc.next();
		for (Airport a : listAirport) {
			if(a.getId().equals(id)) {
				a.setListofhelicopterIDs(listadd);
			}			
		}
		for (String s : listadd) {
			if(listOnAir.contains(s) == true) {
				listOnAir.remove(s);
			}
		}
		System.out.println("Complete!");
		System.out.println();
	}

	public static void addFixedwing() {
		String listid = "";		
		for (Airplane a : listAirplane) {
			if(a instanceof Fixedwing) {
				listid += a.getID()+" ";				
			}
		}
		System.out.println("List id fixedwing: "+listid);

		List<String> listadd = new ArrayList<String>();
		while (true) {
			System.out.print("Input fixedwing id: ");
			listadd.add(sc.next());
			System.out.print("Continue? Y/N :");
			if(sc.next().equals("n")) break;
		}		
		boolean check = false;
		System.out.print("Input Airport ID to add Fixedwing: ");
		String id = sc.next();
		for (Airport a : listAirport) {
			if(a.getId().equals(id)) {				
				a.setListoffixedwingairplaneID(listadd);
				check = true;
			}
		}
		if(check) {
			for (String s : listadd) {
				if(listOnAir.contains(s) == true) {
					listOnAir.remove(s);
				}
			}
			System.out.println("Complete!");
			System.out.println();
		}		

	}

	public static void removeAirplaneFromAirport() {

		String listAirportID = "";
		for (Airport a : listAirport) {			
			listAirportID += a.getId()+" ";			
		}
		System.out.print("List ID Airport: "+listAirportID);
		System.out.println();
		System.out.print("Input Airport ID: ");
		String idAirport = sc.next();

		System.out.print("List of Airplane of Airport "+idAirport+": ");

		for (Airport a : listAirport) {
			if(a.getId().equalsIgnoreCase(idAirport)) {
				System.out.println(a.getListofhelicopterIDs()+" / "+a.getListoffixedwingairplaneID());
			}
		}
		System.out.print("Input airplane id to remove from Airport: ");
		String airp = sc.nextLine();
		
		for (Airport a : listAirport) {
			if(a.getId().equalsIgnoreCase(idAirport)) {		
				if(a.getListofhelicopterIDs().contains(airp)) {
					a.getListofhelicopterIDs().remove(airp);
					listOnAir.add(airp);
				}else {
					a.getListoffixedwingairplaneID().remove(airp);
					listOnAir.add(airp);
				}				
			}
		}
		System.out.println("Complete!");
		System.out.println();


	}

	public static void removeAirplane() {
		System.out.print("Input airplane id to remove: ");
		String airp = sc.nextLine();
		try {
			listAirplane.removeIf(air ->air.getID().equals(airp));
			for (String s : listOnAir) {
				if(s.equals(airp)) {
					listOnAir.remove(s);
				}
			}
			for (Airport a : listAirport) {
				if(a.getListofhelicopterIDs().contains(airp)) {
					a.getListofhelicopterIDs().remove(airp);
				}else {
					a.getListoffixedwingairplaneID().remove(airp);
				}
			}
		} catch (Exception e) {

		}
	}

}
