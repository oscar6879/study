package fa.training.entities;

import java.util.Comparator;

public class AirplaneCompare implements Comparator<Airplane>{

	@Override
	public int compare(Airplane o1, Airplane o2) {
		return o1.getID().compareTo(o2.getID());		
	}

}
