package fa.training.entities;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

public class Airport {
	Scanner sc = new Scanner(System.in);
	private String id, name;
	private int runwaySize, maxFixedWingParkingPlace, maxRotatedWingParkingPlace;
	private List<String> listoffixedwingairplaneID;
	private List<String> listofhelicopterIDs;
	public Airport(String id, String name, int runwaySize, int maxFixedWingParkingPlace, int maxRotatedWingParkingPlace,
			List<String> listoffixedwingairplaneID, List<String> listofhelicopterIDs) {
		super();
		this.id = id;		
		this.name = name;
		this.runwaySize = runwaySize;
		this.maxFixedWingParkingPlace = maxFixedWingParkingPlace;
		this.maxRotatedWingParkingPlace = maxRotatedWingParkingPlace;
		this.listoffixedwingairplaneID = listoffixedwingairplaneID;
		this.listofhelicopterIDs = listofhelicopterIDs;
	}
	public Airport() {
		super();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRunwaySize() {
		return runwaySize;
	}
	public void setRunwaySize(int runwaySize) {
		this.runwaySize = runwaySize;
	}
	public int getMaxFixedWingParkingPlace() {
		return maxFixedWingParkingPlace;
	}
	public void setMaxFixedWingParkingPlace(int maxFixedWingParkingPlace) {
		this.maxFixedWingParkingPlace = maxFixedWingParkingPlace;
	}
	public int getMaxRotatedWingParkingPlace() {
		return maxRotatedWingParkingPlace;
	}
	public void setMaxRotatedWingParkingPlace(int maxRotatedWingParkingPlace) {
		this.maxRotatedWingParkingPlace = maxRotatedWingParkingPlace;
	}
	public List<String> getListoffixedwingairplaneID() {
		return listoffixedwingairplaneID;
	}
	public void setListoffixedwingairplaneID(List<String> listoffixedwingairplaneID) {
		this.listoffixedwingairplaneID = listoffixedwingairplaneID;
	}
	public List<String> getListofhelicopterIDs() {
		return listofhelicopterIDs;
	}
	public void setListofhelicopterIDs(List<String> listofhelicopterIDs) {
		this.listofhelicopterIDs = listofhelicopterIDs;
	}
	
	public void inputAirport() {
		
		System.out.print("Input ID: ");		
		this.id = sc.nextLine();
		System.out.print("Input name: ");
		this.name = sc.nextLine();
		System.out.print("Input runway size: ");
		this.runwaySize = sc.nextInt();
		
		this.listoffixedwingairplaneID = (List<String>) new HashSet<String>();		
		
		this.listofhelicopterIDs = (List<String>) new HashSet<String>();
		//this.listofhelicopterIDs = new ArrayList<String>();
	}
	@Override
	public String toString() {
		return "Airport [id=" + id + ", name=" + name + ", runwaySize=" + runwaySize
				+ ", maxFixedWingParkingPlace=" + maxFixedWingParkingPlace + ", maxRotatedWingParkingPlace="
				+ maxRotatedWingParkingPlace + ", listoffixedwingairplaneID=" + listoffixedwingairplaneID
				+ ", listofhelicopterIDs=" + listofhelicopterIDs + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
