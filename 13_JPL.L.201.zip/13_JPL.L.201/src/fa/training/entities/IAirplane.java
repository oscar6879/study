package fa.training.entities;

public interface IAirplane {
	public void fly();
}
