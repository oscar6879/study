package fa.training.entities;

import java.util.Scanner;

import fa.training.utils.Validator;

public abstract class Airplane implements IAirplane{
	static Scanner sc = new Scanner(System.in);
	private String ID, model;
	private double cruiseSpeed, emptyWeight, maxTakeoffWeight;
	public Airplane(String iD, String model, double cruiseSpeed, double emptyWeight, double maxTakeoffWeight) {
		super();
		ID = iD;
		this.model = model;
		this.cruiseSpeed = cruiseSpeed;
		this.emptyWeight = emptyWeight;
		this.maxTakeoffWeight = maxTakeoffWeight;
	}
	public Airplane() {
		super();
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public double getCruiseSpeed() {
		return cruiseSpeed;
	}
	public void setCruiseSpeed(double cruiseSpeed) {
		this.cruiseSpeed = cruiseSpeed;
	}
	public double getEmptyWeight() {
		return emptyWeight;
	}
	public void setEmptyWeight(double emptyWeight) {
		this.emptyWeight = emptyWeight;
	}
	public double getMaxTakeoffWeight() {
		return maxTakeoffWeight;
	}
	public void setMaxTakeoffWeight(double maxTakeoffWeight) {
		this.maxTakeoffWeight = maxTakeoffWeight;
	}
	public abstract void fly();
	
	public void inputAirPlane() {		
		Validator vali = new Validator();
		do {
			System.out.print("Input ID: ");
			this.ID = sc.next();
		} while (!vali.validID(this.ID));
		
		do {
			System.out.print("Input model: ");
			this.model = sc.next();
		} while (!vali.validModel(this.model));
		
		System.out.print("Input Cruise Speed: ");
		this.cruiseSpeed = sc.nextDouble();
		System.out.print("Input Empty Weight: ");
		this.emptyWeight = sc.nextDouble();
		System.out.print("Input Max Takeoff Weight: ");
		this.maxTakeoffWeight = sc.nextDouble();
	}
	@Override
	public String toString() {
		return "ID=" + ID + ", model=" + model + ", cruiseSpeed=" + cruiseSpeed + ", emptyWeight="
				+ emptyWeight + ", maxTakeoffWeight=" + maxTakeoffWeight ;
	}
	
	
}
