package fa.training.entities;

public class Fixedwing extends Airplane{
	private double minNeededRunwaySize;
	private String planeType;
	@Override
	public void fly() {
		System.out.println("fixed wing");		
	}

	public Fixedwing() {
		super();
	}

	public double getMinNeededRunwaySize() {
		return minNeededRunwaySize;
	}

	public void setMinNeededRunwaySize(double minNeededRunwaySize) {
		this.minNeededRunwaySize = minNeededRunwaySize;
	}


	public String getPlaneType() {
		return planeType;
	}

	public void setPlaneType(String planeType) {
		this.planeType = planeType;
	}

	public Fixedwing(String iD, String model, double cruiseSpeed, double emptyWeight, double maxTakeoffWeight,
			double minNeededRunwaySize, String planeType) {
		super(iD, model, cruiseSpeed, emptyWeight, maxTakeoffWeight);
		this.minNeededRunwaySize = minNeededRunwaySize;
		this.planeType = planeType;
	}

	public void input() {
		this.inputAirPlane();
		System.out.print("Input plane type: ");
		this.planeType = sc.next();
		System.out.print("Input min needed runway size: ");		
		this.minNeededRunwaySize = sc.nextDouble();
	}

	@Override
	public String toString() {
		return "Fixedwing "+super.toString()+", planeType=" + planeType+", minNeededRunwaySize=" + minNeededRunwaySize;
	}



}
