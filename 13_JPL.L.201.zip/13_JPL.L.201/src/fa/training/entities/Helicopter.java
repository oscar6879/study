package fa.training.entities;

public class Helicopter extends Airplane{
	private double range;
	
	public Helicopter() {
		super();
	}

	public Helicopter(String iD, String model, double cruiseSpeed, double emptyWeight, double maxTakeoffWeight,
			double range) {
		super(iD, model, cruiseSpeed, emptyWeight, maxTakeoffWeight);
		this.range = range;
	}

	public double getRange() {
		return range;
	}

	public void setRange(double range) {
		this.range = range;
	}

	@Override
	public void fly() {
		System.out.println("rotated wing");		
	}
	public void input() {
		this.inputAirPlane();		
		System.out.print("Input range: ");
		this.range = sc.nextDouble();
	}

	@Override
	public String toString() {
		return "Helicopter " +super.toString()+ ", range=" + range;
	}
	
	
}
