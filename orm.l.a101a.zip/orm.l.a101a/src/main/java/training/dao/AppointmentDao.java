package training.dao;

public class AppointmentDao extends EntityDao<Object> {

}
