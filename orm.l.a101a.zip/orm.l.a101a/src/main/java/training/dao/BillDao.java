package training.dao;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import training.entities.Bill;
import training.utils.HibernateUtils;

public class BillDao extends EntityDao<Object> {
	
	private static SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
	/*
	 * Search all Bills with a specific bill_date 
	 */
	public List<Bill> searchBillByDate(LocalDate date) {
		Session session = sessionFactory.openSession();
		String hql = "from Bill";

		try {
			Query query = session.createQuery(hql);
			return (List<Bill>) query.list();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (session != null) {
				session.close();
			}
		}
		return null;
	}
}
