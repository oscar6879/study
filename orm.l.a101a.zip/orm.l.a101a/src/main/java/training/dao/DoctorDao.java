package training.dao;

public class DoctorDao extends EntityDao<Object> {

}
