package training.dao;

public class PaymentDao extends EntityDao<Object> {

}
