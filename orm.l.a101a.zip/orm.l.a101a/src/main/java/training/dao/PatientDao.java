package training.dao;

public class PatientDao extends EntityDao<Object> {

}
