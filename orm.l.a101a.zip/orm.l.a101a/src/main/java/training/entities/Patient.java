package training.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Proxy;

@Entity
@Proxy
public class Patient{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Pat_ID")
	private int patId;
	
	@Column(name="Pat_First_Name")
	private String patFirstname;
	
	@Column(name="Pat_Last_Name")
	private String patLastName;
	
	@Column(name="Pat_Address")
	private String patAddress;
	
	@Column(name="Pat_City")
	private String patCity;
	
	@Column(name="Pat_State")
	private String patState;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "appPatId", cascade = CascadeType.ALL)
	private Set<Appointment> setPatApp = new HashSet<>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "payPatId", cascade = CascadeType.ALL)
	private Set<Payment> setPatPay = new HashSet<>();

	public Patient(String patFirstname, String patLastName, String patAddress, String patCity, String patState) {
		super();
		this.patFirstname = patFirstname;
		this.patLastName = patLastName;
		this.patAddress = patAddress;
		this.patCity = patCity;
		this.patState = patState;
	}

	public Patient() {
		super();
	}

	@Override
	public String toString() {
		return "Patient [patId=" + patId + ", patFirstname=" + patFirstname + ", patLastName=" + patLastName
				+ ", patAddress=" + patAddress + ", patCity=" + patCity + ", patState=" + patState + "]";
	}
	
	
	

	
}
