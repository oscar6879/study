package training.entities;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Proxy;

@Entity
@Proxy
public class Appointment {

	@Id
	@Column(name = "App_Date")
	private LocalDate appDate;

	@Column(name = "App_Time")
	private LocalTime appTime;

	@Column(name = "App_Duration")
	private int appDuration;

	@Column(name = "App_Reason")
	private String appReason;

	@ManyToOne
	@JoinColumn(name = "App_Doc_Number", referencedColumnName = "Doc_Number")
	private Doctor appDocNumber;

	@ManyToOne
	@JoinColumn(name = "App_Pat_ID", referencedColumnName = "Pat_ID")
	private Patient appPatId;

	@OneToOne(cascade = CascadeType.ALL,mappedBy = "billDate",fetch = FetchType.LAZY)
	private Bill appBill;

	public Appointment(LocalDate appDate, LocalTime appTime, int appDuration, String appReason, Doctor appDocNumber,
			Patient appPatId) {
		super();
		this.appDate = appDate;
		this.appTime = appTime;
		this.appDuration = appDuration;
		this.appReason = appReason;
		this.appDocNumber = appDocNumber;
		this.appPatId = appPatId;
	}

	public Appointment() {
		super();
	}

	@Override
	public String toString() {
		return "Appointment [appDate=" + appDate + ", appTime=" + appTime + ", appDuration=" + appDuration
				+ ", appReason=" + appReason + ", appDocNumber=" + appDocNumber + ", appPatId=" + appPatId + "]";
	}
	
	
	
	

}
