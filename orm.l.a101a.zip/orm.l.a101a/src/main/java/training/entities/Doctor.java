package training.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Proxy;
@Entity
@Proxy
public class Doctor{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Doc_Number")
	private int docNumber;
	
	@Column(name="Doc_Firstname")	
	private String docFirstName;
	
	
	@Column(name="Doc_Lastname")
	private String docLastName;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "appDocNumber", cascade = CascadeType.ALL)
	private Set<Appointment> setDocApp = new HashSet<>();

	public Doctor(String docFirstName, String docLastName) {
		super();
		this.docFirstName = docFirstName;
		this.docLastName = docLastName;
	}

	public Doctor() {
		super();
	}

	@Override
	public String toString() {
		return "Doctor [docNumber=" + docNumber + ", docFirstName=" + docFirstName + ", docLastName=" + docLastName
				+ "]";
	}
	
	
}
