package training.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Proxy;

@Entity
@Proxy
public class Bill {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Bill_Number")
	private int billNumber;
	
	@OneToOne
	@JoinColumn(name = "Bill_Date",referencedColumnName = "App_Date")
	private Appointment billDate;
	
	@Column(name="Bill_Status")
	private String billStatus;	
	
	@OneToMany(mappedBy="payBillNumber", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private Set<Payment> setBillPay = new HashSet<>();

	public Bill(Appointment billDate, String billStatus) {
		super();
		this.billDate = billDate;
		this.billStatus = billStatus;
	}

	public Bill() {
		super();
	}

	@Override
	public String toString() {
		return "Bill [billNumber=" + billNumber + ", billDate=" + billDate + ", billStatus=" + billStatus + "]";
	}

	

}
