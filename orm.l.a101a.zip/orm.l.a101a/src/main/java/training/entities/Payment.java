package training.entities;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import org.hibernate.annotations.Proxy;

@Entity
@Proxy
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Pay_Receiptnum")
	private int payReceiptnum;

	@Column(name = "Pay_Date")
	private LocalDate payDate;

	@Column(name = "Pay_Method")
	private String payMethod;

	@Column(name = "Pay_Amount", columnDefinition = "decimal(9,2)")
	private double payAmount;

	@ManyToOne
	@JoinColumn(name = "Pay_Bill_Number", referencedColumnName = "Bill_number")
	private Bill payBillNumber;

	@ManyToOne
	@JoinColumn(name = "Pay_Pat_ID", referencedColumnName = "Pat_ID")
	private Patient payPatId;

	public Payment(LocalDate payDate, String payMethod, double payAmount, Bill payBillNumber, Patient payPatId) {
		super();
		this.payDate = payDate;
		this.payMethod = payMethod;
		this.payAmount = payAmount;
		this.payBillNumber = payBillNumber;
		this.payPatId = payPatId;
	}

	public Payment() {
		super();
	}

	@Override
	public String toString() {
		return "Payment [payReceiptnum=" + payReceiptnum + ", payDate=" + payDate + ", payMethod=" + payMethod
				+ ", payAmount=" + payAmount + ", payBillNumber=" + payBillNumber + ", payPatId=" + payPatId + "]";
	}
	
	

}
