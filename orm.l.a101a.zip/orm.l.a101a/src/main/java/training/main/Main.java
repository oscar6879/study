package training.main;

import training.utils.Menu;

public class Main {
	public static void main(String[] args) {
		Menu.MainMenu();

	}
}
