package training.utils;

import java.time.LocalDate;
import java.time.LocalTime;

import training.dao.EntityDao;
import training.entities.Appointment;
import training.entities.Bill;
import training.entities.Doctor;
import training.entities.Patient;
import training.entities.Payment;

public class AddData {
	public static void addData() {
		EntityDao<Object> entityDao = new EntityDao<>();

		// insert list doctor into database
		Doctor doctor1 = new Doctor("bac", "si 1");
		entityDao.save(doctor1);

		Doctor doctor2 = new Doctor("bac", "si 2");
		entityDao.save(doctor2);

		Doctor doctor3 = new Doctor("bac", "si 3");
		entityDao.save(doctor3);

		// insert list patient into database
		Patient patient1 = new Patient("Benh", "Nhan 1", "dia chi 1", "thanh pho 1", "tinh 1");
		entityDao.save(patient1);

		Patient patient2 = new Patient("Benh", "Nhan 2", "dia chi 2", "thanh pho 2", "tinh 2");
		entityDao.save(patient2);

		Patient patient3 = new Patient("Benh", "Nhan 3", "dia chi 3", "thanh pho 3", "tinh 3");
		entityDao.save(patient3);

		// insert list Appointment into database
		Appointment appointment1 = new Appointment(LocalDate.of(2021, 10, 1), LocalTime.of(10, 10), 10, "Benh 1",
				doctor1, patient2);
		entityDao.save(appointment1);

		Appointment appointment2 = new Appointment(LocalDate.of(2021, 10, 2), LocalTime.of(10, 30), 11, "Benh 2",
				doctor1, patient3);
		entityDao.save(appointment2);

		Appointment appointment3 = new Appointment(LocalDate.of(2021, 10, 3), LocalTime.of(10, 50), 12, "Benh 3",
				doctor2, patient1);
		entityDao.save(appointment3);

		Appointment appointment4 = new Appointment(LocalDate.of(2021, 10, 4), LocalTime.of(11, 10), 13, "Benh 4",
				doctor2, patient3);
		entityDao.save(appointment4);

		Appointment appointment5 = new Appointment(LocalDate.of(2021, 10, 5), LocalTime.of(11, 30), 14, "Benh 5",
				doctor3, patient1);
		entityDao.save(appointment5);

		Appointment appointment6 = new Appointment(LocalDate.of(2021, 10, 6), LocalTime.of(11, 50), 15, "Benh 6",
				doctor3, patient2);
		entityDao.save(appointment6);

		// insert list Bill into database
		Bill bill1 = new Bill(appointment1, "not paid");
		entityDao.save(bill1);

		Bill bill2 = new Bill(appointment2, "paid");
		entityDao.save(bill2);

		Bill bill3 = new Bill(appointment3, "not paid");
		entityDao.save(bill3);

		Bill bill4 = new Bill(appointment4, "paid");
		entityDao.save(bill4);

		Bill bill5 = new Bill(appointment5, "not paid");
		entityDao.save(bill5);

		Bill bill6 = new Bill(appointment6, "paid");
		entityDao.save(bill6);

		// insert list Paid Payment into database
		Payment payment2 = new Payment(LocalDate.of(2021, 10, 3), "cash", 1000, bill2, patient3);
		entityDao.save(payment2);

		Payment payment4 = new Payment(LocalDate.of(2021, 10, 5), "card", 2000, bill4, patient3);
		entityDao.save(payment4);

		Payment payment6 = new Payment(LocalDate.of(2021, 10, 7), "cash", 3000, bill6, patient2);
		entityDao.save(payment6);

	}
}
