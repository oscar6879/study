package training.utils;

import java.util.Scanner;

import training.dao.EntityDao;
import training.entities.Appointment;
import training.entities.Bill;
import training.entities.Doctor;
import training.entities.Patient;
import training.entities.Payment;

public class Menu {
	static Scanner sc = new Scanner(System.in);
	static EntityDao entityDao = new EntityDao<>();

	// Exit function
	public static void exit() {
		for (int i = 0; i < 60; i++)
			System.out.println();
		System.out.println("Ban da thoat khoi chuong trinh. Cam on!");
	}

	// Main menu
	public static void MainMenu() {
		System.out.println("----//----//----//----//----//----//----//----//----");
		System.out.println("Nhap lua chon chuong trinh:");
		System.out.println("0. Add data into database");
		System.out.println("1. View all Doctor");
		System.out.println("2. View all Customer");
		System.out.println("3. View all Appointment");
		System.out.println("4. View all Bill");
		System.out.println("5. View all Payment");
		System.out.println("6. Get Doctor by id");
		System.out.println("7. Get Customer Test Type by id");
		System.out.println("8. Get Appointment Type by id");
		System.out.println("9. Get Bill by id");
		System.out.println("10. Get Payment Type by id");
		System.out.println("11. Exit");
		System.out.println("Nhan phim 11 neu muon thoat chuong trinh");
		System.out.println("------------------------------------------");
		System.out.println("Lua chon cua ban la: ");
		int choice0 = sc.nextInt();
		switch (choice0) {
		case 0:
			AddData.addData();
			MainMenu();
			break;
		case 1:
			entityDao.print(entityDao.getAll("Doctor"));
			MainMenu();
			break;
		case 2:
			entityDao.print(entityDao.getAll("Patient"));
			MainMenu();
			break;
		case 3:
			entityDao.print(entityDao.getAll("Appointment"));
			MainMenu();
			break;
		case 4:
			entityDao.print(entityDao.getAll("Bill"));
			MainMenu();
			break;
		case 5:
			entityDao.print(entityDao.getAll("Payment"));
			MainMenu();
			break;
		case 6:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new Doctor(),sc.nextInt()));
			MainMenu();
			break;
		case 7:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new Patient(),sc.nextInt()));
			MainMenu();
			break;
		case 8:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new Appointment(),sc.nextInt()));
			MainMenu();
			break;
		case 9:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new Bill(),sc.nextInt()));
			MainMenu();
			break;
		case 10:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new Payment(),sc.nextInt()));
			MainMenu();
			break;
		case 11:
			exit();
			break;
		default:
			System.out.println("Ban da nhap sai. Xin moi nhap lai lua chon");
			MainMenu();
			break;
		}
	}

	// Main menu
	public static void SubMenu1() {
		System.out.println("----//----//----//----//----//----//----//----//----");
		System.out.println("Nhap lua chon chuong trinh:");
		System.out.println("Nhan phim 1 ...");
		System.out.println("Nhan phim 2 ...");
		System.out.println("Nhan phim 3 de quay lai menu truoc");
		System.out.println("Nhan phim 4 neu muon thoat chuong trinh");
		System.out.println("------------------------------------------");
		System.out.println("Lua chon cua ban la: ");
		int choice0 = sc.nextInt();
		switch (choice0) {
		case 1:
			break;
		case 2:
			break;
		case 3:
			MainMenu();
			break;
		case 4:
			exit();
			break;
		default:
			System.out.println("Ban da nhap sai. Xin moi nhap lai lua chon");
			SubMenu1();
			break;
		}
	}

}
