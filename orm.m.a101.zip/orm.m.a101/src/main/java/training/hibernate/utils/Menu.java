package training.hibernate.utils;

import java.util.List;
import java.util.Scanner;

import training.hibernate.dao.EntityDao;
import training.hibernate.entities.Room;
import training.hibernate.entities.RoomDetail;
import training.hibernate.entities.Seat;

public class Menu {
	static Scanner sc = new Scanner(System.in);

	// Exit function
	public static void exit() {
		for (int i = 0; i < 60; i++)
			System.out.println();
		System.out.println("Ban da thoat khoi chuong trinh. Cam on!");
	}

	// Main menu
	public static void MainMenu() {
		EntityDao entityDao = new EntityDao<>();

		System.out.println("----//----//----//----//----//----//----//----//----");
		System.out.println("1. View all Room");
		System.out.println("2. View all Seat");
		System.out.println("3. View all Room Detail");
		System.out.println("4. Get Room by id");
		System.out.println("5. Get Seat by id");
		System.out.println("6. Get Room Detail by id");
		System.out.println("7. Exit");
		System.out.println("Nhan phim 7 neu muon thoat chuong trinh");
		System.out.println("------------------------------------------");
		System.out.println("Lua chon cua ban la: ");
		int choice0 = sc.nextInt();
		switch (choice0) {
		case 1:
			entityDao.print(entityDao.getAll("Room"));
			MainMenu();
			break;
		case 2:
			entityDao.print(entityDao.getAll("Seat"));
			MainMenu();
			break;
		case 3:
			entityDao.print(entityDao.getAll("RoomDetail"));
			break;
		case 4:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new Room(),sc.nextInt()));
			MainMenu();
			break;
		case 5:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new Seat(),sc.nextInt()));
			MainMenu();
			break;
		case 6:
			System.err.println("Nhap Id: ");
			System.err.println(entityDao.getById(new RoomDetail(),sc.nextInt()));
			MainMenu();
			break;
		case 7:
			exit();
			break;
		default:
			System.out.println("Ban da nhap sai. Xin moi nhap lai lua chon");
			MainMenu();
			break;
		}
	}

	// Main menu
	public static void SubMenu1() {
		System.out.println("----//----//----//----//----//----//----//----//----");
		System.out.println("Nhap lua chon chuong trinh:");
		System.out.println("Nhan phim 1 ...");
		System.out.println("Nhan phim 2 ...");
		System.out.println("Nhan phim 3 de quay lai menu truoc");
		System.out.println("Nhan phim 4 neu muon thoat chuong trinh");
		System.out.println("------------------------------------------");
		System.out.println("Lua chon cua ban la: ");
		int choice0 = sc.nextInt();
		switch (choice0) {
		case 1:
			break;
		case 2:
			break;
		case 3:
			MainMenu();
			break;
		case 4:
			exit();
			break;
		default:
			System.out.println("Ban da nhap sai. Xin moi nhap lai lua chon");
			SubMenu1();
			break;
		}
	}

}
