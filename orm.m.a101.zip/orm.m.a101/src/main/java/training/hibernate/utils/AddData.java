package training.hibernate.utils;

import java.sql.Date;

import training.hibernate.dao.EntityDao;
import training.hibernate.entities.Room;
import training.hibernate.entities.RoomDetail;
import training.hibernate.entities.Seat;

public class AddData {
	public static void addData() {
		EntityDao entityDao = new EntityDao<>();
		
		Room room1 = new Room("room1",1);
		Room room2 = new Room("room2",2);
		Room room3 = new Room("room3",3);
		entityDao.save(room1);
		entityDao.save(room2);
		entityDao.save(room3);
		
		Seat seat1 = new Seat("seat1", 1, "Available","VIP",room1);
		Seat seat2 = new Seat("seat2", 2, "Not Available","Normal",room2);
		Seat seat3 = new Seat("seat3", 3, "Booked","VIP",room2);
		Seat seat4 = new Seat("seat4", 4, "Available","Normal",room3);
		Seat seat5 = new Seat("seat5", 5, "Not Available","VIP",room3);
		Seat seat6 = new Seat("seat6", 6, "Booked","Normal",room3);
		entityDao.save(seat1);
		entityDao.save(seat2);
		entityDao.save(seat3);
		entityDao.save(seat4);
		entityDao.save(seat5);
		entityDao.save(seat6);
		
		RoomDetail roomDetail1 = new RoomDetail(2,Date.valueOf("2021-10-10"),"good",room3);
		RoomDetail roomDetail2 = new RoomDetail(3,Date.valueOf("2021-10-09"),"bad",room2);
		RoomDetail roomDetail3 = new RoomDetail(4,Date.valueOf("2021-10-08"),"medium",room1);
		entityDao.save(roomDetail1);
		entityDao.save(roomDetail2);
		entityDao.save(roomDetail3);
	}
}
