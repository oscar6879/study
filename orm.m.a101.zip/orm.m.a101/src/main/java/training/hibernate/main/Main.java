package training.hibernate.main;

import training.hibernate.utils.AddData;
import training.hibernate.utils.Menu;

public class Main {
	public static void main(String[] args) {
		AddData.addData();
		Menu.MainMenu();
	}
	
}
