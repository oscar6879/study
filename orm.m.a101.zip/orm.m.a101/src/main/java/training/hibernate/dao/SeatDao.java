package training.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import training.hibernate.entities.Seat;
import training.hibernate.entities.Seat;
import training.hibernate.entities.Seat;
import training.hibernate.utils.HibernateUtils;

public class SeatDao extends EntityDao {
	private static SessionFactory sessionFactory = HibernateUtils.getSessionFactory();

	/*
	 * Get
	 */
	public Seat get(int id) {
		Session session = sessionFactory.openSession();
		try {

			return (Seat) session.get(Seat.class, id);
			
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}

}
