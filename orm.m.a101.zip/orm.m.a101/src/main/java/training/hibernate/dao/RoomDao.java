package training.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import training.hibernate.entities.Room;
import training.hibernate.utils.HibernateUtils;


public class RoomDao extends EntityDao {
	private static SessionFactory sessionFactory = HibernateUtils.getSessionFactory();

	/*
	 * Get
	 */
	public Room get(int id) {
		Session session = sessionFactory.openSession();
		try {

			return (Room) session.get(Room.class, id);
			
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}

}
