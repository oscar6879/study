package training.hibernate.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import training.hibernate.entities.RoomDetail;
import training.hibernate.utils.HibernateUtils;

public class RoomDetailDao {
	private static SessionFactory sessionFactory = HibernateUtils.getSessionFactory();

	/*
	 * Get
	 */
	public RoomDetail get(int id) {
		Session session = sessionFactory.openSession();
		try {

			return (RoomDetail) session.get(RoomDetail.class, id);

		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}

	/*
	 * Create
	 */
	public void save(RoomDetail obj) {
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();

			// ★ Insert into Table
			session.save(obj);

			transaction.commit();
		} catch (HibernateException e) {
			if (transaction != null)
				transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	/*
	 * Delete
	 */
	public void delete(RoomDetail obj) {
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();

			// Delete it
			session.delete(obj);

			transaction.commit();
		} catch (HibernateException e) {
			if (transaction != null)
				transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

}
