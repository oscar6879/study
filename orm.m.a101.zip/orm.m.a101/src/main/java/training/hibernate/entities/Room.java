package training.hibernate.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Proxy;

@Proxy
@Entity
@Table(name = "CINEMA_ROOM", schema = "MovieTheater")
public class Room {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CINEMA_ROOM_ID")
	private int roomId;

	@Column(name = "CINEMA_ROOM_NAME", unique = true)
	private String roomName;

	@Column(name = "SEAT_QUANTITY")
	private int seatQuantity;

	@OneToMany(mappedBy = "room")
	private Set<Seat> seat = new HashSet<>();

	@OneToOne(mappedBy = "detailRoomId",fetch = FetchType.LAZY)
	private RoomDetail roomDetail;

	/**
	 * @return the roomId
	 */
	public int getRoomId() {
		return roomId;
	}

	/**
	 * @param roomId the roomId to set
	 */
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	/**
	 * @return the roomName
	 */
	public String getRoomName() {
		return roomName;
	}

	/**
	 * @param roomName the roomName to set
	 */
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	/**
	 * @return the seatQuantity
	 */
	public int getSeatQuantity() {
		return seatQuantity;
	}

	/**
	 * @param seatQuantity the seatQuantity to set
	 */
	public void setSeatQuantity(int seatQuantity) {
		this.seatQuantity = seatQuantity;
	}

	/**
	 * @return the seat
	 */
	public Set<Seat> getSeat() {
		return seat;
	}

	/**
	 * @param seat the seat to set
	 */
	public void setSeat(Set<Seat> seat) {
		this.seat = seat;
	}

	/**
	 * @return the roomDetail
	 */
	public RoomDetail getRoomDetail() {
		return roomDetail;
	}

	/**
	 * @param roomDetail the roomDetail to set
	 */
	public void setRoomDetail(RoomDetail roomDetail) {
		this.roomDetail = roomDetail;
	}

	public Room() {
		super();
	}

	public void addSeat(Seat seat){
		this.seat.add(seat);
	}
	
	public void removeSeat(Seat seat) {
		this.seat.remove(seat);
	}
	
	public void removeAllSeat() {
		Set<Seat> seat = new HashSet<>(this.seat);
		this.seat.clear();
	}

	public Room(String roomName, int seatQuantity) {
		super();
		this.roomName = roomName;
		this.seatQuantity = seatQuantity;
	}

	@Override
	public String toString() {
		return "Room [roomId=" + roomId + ", roomName=" + roomName + ", seatQuantity=" + seatQuantity + "]";
	}

	
	
	
	
}
