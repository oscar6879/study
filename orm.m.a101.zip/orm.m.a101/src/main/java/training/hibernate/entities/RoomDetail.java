package training.hibernate.entities;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CINEMA_ROOM_DETAIL",schema = "MovieTheater")
public class RoomDetail {

	@Id
	@GeneratedValue
	@Column(name = "CINEMA_ROOM_DETAIL_ID")
	private int roomDetailId;

	@Column(name = "ROOM_RATE")
	private int roomRate;

	@Column(name = "ACTIVE_DATE")
	@Temporal(TemporalType.DATE)
	private Date activeDate;

	/**
	 * @return the roomDetailId
	 */
	public int getRoomDetailId() {
		return roomDetailId;
	}

	/**
	 * @param roomDetailId the roomDetailId to set
	 */
	public void setRoomDetailId(int roomDetailId) {
		this.roomDetailId = roomDetailId;
	}

	/**
	 * @return the roomRate
	 */
	public int getRoomRate() {
		return roomRate;
	}

	/**
	 * @param roomRate the roomRate to set
	 */
	public void setRoomRate(int roomRate) {
		this.roomRate = roomRate;
	}

	/**
	 * @return the activeDate
	 */
	public Date getActiveDate() {
		return activeDate;
	}

	/**
	 * @param activeDate the activeDate to set
	 */
	public void setActiveDate(Date activeDate) {
		this.activeDate = activeDate;
	}

	/**
	 * @return the roomDescription
	 */
	public String getRoomDescription() {
		return roomDescription;
	}

	/**
	 * @param roomDescription the roomDescription to set
	 */
	public void setRoomDescription(String roomDescription) {
		this.roomDescription = roomDescription;
	}

	/**
	 * @return the detailRoomId
	 */
	public Room getDetailRoomId() {
		return detailRoomId;
	}

	/**
	 * @param detailRoomId the detailRoomId to set
	 */
	public void setDetailRoomId(Room detailRoomId) {
		this.detailRoomId = detailRoomId;
	}

	@Column(name = "ROOM_DESCRIPTION", columnDefinition = "varchar(250)", nullable = false)
	private String roomDescription;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CINEMA_ROOM_ID", nullable = false, referencedColumnName = "CINEMA_ROOM_ID")
	private Room detailRoomId;

	public RoomDetail(int roomRate, Date activeDate, String roomDescription, Room detailRoomId) {
		super();
		this.roomRate = roomRate;
		this.activeDate = activeDate;
		this.roomDescription = roomDescription;
		this.detailRoomId = detailRoomId;
	}

	public RoomDetail() {
		super();
	}

	@Override
	public String toString() {
		return "RoomDetail [roomDetailId=" + roomDetailId + ", roomRate=" + roomRate + ", activeDate=" + activeDate
				+ ", roomDescription=" + roomDescription + ", detailRoomId=" + detailRoomId + "]";
	}

	
}
