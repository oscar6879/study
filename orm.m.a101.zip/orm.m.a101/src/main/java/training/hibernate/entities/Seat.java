package training.hibernate.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "SEAT",schema = "MovieTheater")
public class Seat {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SEAT_ID")
	private int seatID;

	@Column(name = "SEAT_COLUMN")
	private String seatColumn;

	@Column(name = "SEAT_ROW")
	private int seatRow;

	@Column(name = "SEAT_STATUS")
	private String seatStatus;

	@Column(name = "SEAT_TYPE")
	private String seatType;

	@ManyToOne
	@JoinColumn(name = "CINEMA_ROOM_ID", nullable = false)
	private Room room;

	/**
	 * @return the seatID
	 */
	public int getSeatID() {
		return seatID;
	}

	/**
	 * @param seatID the seatID to set
	 */
	public void setSeatID(int seatID) {
		this.seatID = seatID;
	}

	/**
	 * @return the seatColumn
	 */
	public String getSeatColumn() {
		return seatColumn;
	}

	/**
	 * @param seatColumn the seatColumn to set
	 */
	public void setSeatColumn(String seatColumn) {
		this.seatColumn = seatColumn;
	}

	/**
	 * @return the seatRow
	 */
	public int getSeatRow() {
		return seatRow;
	}

	/**
	 * @param seatRow the seatRow to set
	 */
	public void setSeatRow(int seatRow) {
		this.seatRow = seatRow;
	}

	/**
	 * @return the seatStatus
	 */
	public String getSeatStatus() {
		return seatStatus;
	}

	/**
	 * @param seatStatus the seatStatus to set
	 */
	public void setSeatStatus(String seatStatus) {
		this.seatStatus = seatStatus;
	}

	/**
	 * @return the seatType
	 */
	public String getSeatType() {
		return seatType;
	}

	/**
	 * @param seatType the seatType to set
	 */
	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}

	/**
	 * @return the room
	 */
	public Room getRoom() {
		return room;
	}

	/**
	 * @param room the room to set
	 */
	public void setRoom(Room room) {
		this.room = room;
	}

	

	public Seat(String seatColumn, int seatRow, String seatStatus, String seatType, Room room) {
		super();
		this.seatColumn = seatColumn;
		this.seatRow = seatRow;
		this.seatStatus = seatStatus;
		this.seatType = seatType;
		this.room = room;
	}

	public Seat() {
		super();
	}

	@Override
	public String toString() {
		return "Seat [seatID=" + seatID + ", seatColumn=" + seatColumn + ", seatRow=" + seatRow + ", seatStatus="
				+ seatStatus + ", seatType=" + seatType + ", room=" + room + "]";
	}

}
