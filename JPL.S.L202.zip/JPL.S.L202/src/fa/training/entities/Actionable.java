package fa.training.entities;

/**
 * 
 * @author DieuNT1
 *
 */
public interface Actionable {
    /**
     * An abstract method.
     */
    void toSchool();
}
