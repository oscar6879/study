package fa.training.entities;

public class Sedan extends Car{
	
	int length;

	public Sedan(int speed, double regularPrice, String color, int len) {
		super(speed, regularPrice, color);
		// TODO Auto-generated constructor stub
		this.length = len;
	}

	@Override
	public double getSalePrice() {
		// TODO Auto-generated method stub
		if (this.length >20) {
			return super.regularPrice*0.95;
		}
		else {
		return super.regularPrice*0.9;
		}
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ("Sedan, Speed = "+super.speed+", regular price= "+super.regularPrice+
				", color= "+super.color+", Length= "+ this.length+", Sale price= "+this.getSalePrice());
	}

}
