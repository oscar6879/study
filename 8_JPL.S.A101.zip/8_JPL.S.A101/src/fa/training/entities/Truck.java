package fa.training.entities;

public class Truck extends Car {
	
	int weight;


	public Truck(int speed, double regularPrice, String color, int weight) {
		super(speed, regularPrice, color);
		this.weight = weight;
	}


	@Override
	public double getSalePrice() {
		if (weight > 2000) {
		return super.regularPrice*0.9;
		}
		else {
			return super.regularPrice*0.8;
		}
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ("Truck, Speed = "+super.speed+", regular price= "+super.regularPrice+
				", color= "+super.color+", weight= "+ this.weight+", Sale price= "+this.getSalePrice());
	}
	

	

}
