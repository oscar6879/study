package fa.training.entities;

public class Ford extends Car{

	int year;
	int manufacturerDiscount;

	
	public Ford(int speed, double regularPrice, String color, int y, int manuDis) {
		super(speed, regularPrice, color);
		// TODO Auto-generated constructor stub
		this.year = y;
		this.manufacturerDiscount = manuDis;
	}


	@Override
	public double getSalePrice() {
		// TODO Auto-generated method stub
		return (super.regularPrice - this.manufacturerDiscount);
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ("Ford, Speed = "+super.speed+", regular price= "+super.regularPrice+
				", color= "+super.color+", year= "+ this.year+
				", Manufacture Discount= "+this.manufacturerDiscount+", Sale price= "+this.getSalePrice());
	}

}
