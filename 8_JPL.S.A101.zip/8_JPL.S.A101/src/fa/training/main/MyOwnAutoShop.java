package fa.training.main;

import fa.training.entities.Car;
import fa.training.entities.Ford;
import fa.training.entities.Sedan;
import fa.training.entities.Truck;


public class MyOwnAutoShop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Car car1= new Sedan(60,7000,"red",18);
		Car car2= new Ford(80,6000,"blue",2018,500);
		Car car3= new Ford(70,5000,"green",2019,300);
		Car car4= new Truck(75,8000,"gray",2100);
		
		Car[] cars = {car1,car2,car3,car4};
		
		for (int i=0; i<4; i++)
		{
			System.out.println(cars[i].toString());
		}
	}

}
