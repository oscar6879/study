package excercise.arraylist;

import java.util.ArrayList;
import java.util.Collections;

public class DemoArrayList {
  
  /**
   * The main method
   * @param args
   */
  public static void main(String[] args) {
    
    List<String> listSubject = new ArrayList<>();
    
    listSubject.add("IOS");
    listSubject.add("Java");
    listSubject.add("PHP");
    listSubject.add("Android");
    listSubject.add("Python");
    listSubject.add("Java"); // list allow contains duplicate record
    listSubject.add("C");
    
    // display all subject
    System.out.print("There are "+listSubject.size()+" subject: ");
    display(listSubject);
    
    //Retrieve the an element at a given index
    String popularLanguage = listSubject.get(1);
    System.out.println("This is a language program popular in the world:" + popularLanguage);
    
    //Remove an element at a given index
    listSubject.remove(listSubject.size()-1);
    System.out.print("There are " + listSubject.size()+ "subject after remove a element : ");
    display(listSubject);
    
    // Modify the element at a given index
    listSubject.set(listSubject.size()-1, "Ruby");
    System.out.print("List after modify: ");
    display(listSubject);
    
    // sort a list string.
    Collections.sort(listSubject); // String has implement comparable.
    System.out.print("List after sort: ");
    display(listSubject);
  }
  
  /**
   * this method to show all element in list.
   * @param listSubject
   */
  public static void display(ArrayList<String> listSubject) {
    
    for(String subject : listSubject) {
      System.out.print(subject + " ");
    }
    System.out.println();
  }
}
