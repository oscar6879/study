package excercise.treemap;

public class Department implements Comparable<Department> {
  private String departmentCode;
  private String departmentName;
  
  public Department() {
    super();
  }

  public Department(String departmentCode, String departmentName) {
    super();
    this.departmentCode = departmentCode;
    this.departmentName = departmentName;
  }

  public String getDepartmentCode() {
    return departmentCode;
  }

  public void setDepartmentCode(String departmentCode) {
    this.departmentCode = departmentCode;
  }

  public String getDepartmentName() {
    return departmentName;
  }

  public void setDepartmentName(String departmentName) {
    this.departmentName = departmentName;
  }

  @Override
  public String toString() {
    return departmentCode+"\t"+ departmentName;
  }

  @Override
  public int compareTo(Department o) {
    return departmentCode.compareTo(o.departmentCode);
  }
  
}
