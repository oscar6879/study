package excercise.treemap;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class DemoTreeMap {
  /**
   * The main method.
   * @param args
   */
  public static void main(String[] args) {
    Map<Department,String> listDepartment = new TreeMap<>();
    Department department1 = new Department("C", "Fresher Academy");
    Department department2 = new Department("A", "MI8");
    Department department3 = new Department("B", "FA");
    
    listDepartment.put(department1, "Hoa Lac");
    listDepartment.put(department2, "Da Nang");
    listDepartment.put(department3, "Sai Gon");
    
    //display all elements.
    System.out.println("All department:");
    display(listDepartment);
    // retrieve a special element
    System.out.println("Location of department "+ department3.getDepartmentName()
    +" is :"+listDepartment.get(department3)); // map get value by key.
    
    // return true if exist key in map and opposite.
   System.out.println("Check exist:" +listDepartment.containsKey(department1));
   
   //remove element.
   listDepartment.remove(department2);
   System.out.println("All department after an element:");
   display(listDepartment);
  }
  
  /**
   * this method to display element in map.
   * @param listDepartment
   */
  public static void display(Map<Department, String> listDepartment) {
    Set<Department> listKey = listDepartment.keySet(); // get all key in map.
    Iterator<Department> list = listKey.iterator();
    while (list.hasNext()) {
      Department department = (Department) list.next();
      System.out.println(department.toString() +":" + listDepartment.get(department));
    }
  }
}
