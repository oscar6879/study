package excercise.hashset;

public class Student {

  private String studentCode;
  private String studentName;

  public Student() {
    super();
  }

  public Student(String studentCode, String studentName) {
    super();
    this.studentCode = studentCode;
    this.studentName = studentName;
  }

  public String getStudentCode() {
    return studentCode;
  }

  public void setStudentCode(String studentCode) {
    this.studentCode = studentCode;
  }

  public String getStudentName() {
    return studentName;
  }

  public void setStudentName(String studentName) {
    this.studentName = studentName;
  }

  @Override
  public String toString() {
    return studentCode + " \t" + studentName;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Student studentOther = (Student) obj;
    if (studentCode == null) {
      if (studentOther.getStudentCode() != null)
        return false;
    } else if (!studentCode.equals(studentOther.getStudentCode())) {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result
        + ((studentCode == null) ? 0 : studentCode.hashCode());
    return result;
  }

}
