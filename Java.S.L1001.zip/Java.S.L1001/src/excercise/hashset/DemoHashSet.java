package excercise.hashset;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class DemoHashSet {
  /**
   * The main method
   * @param args
   */
  public static void main(String[] args) {
    Set<Student> setStudent = new HashSet<>();
    
    List<Student> listStudent = new ArrayList<>();
    
    Student student1 = new Student("FA1","Hai");
    Student student2 = new Student("FA2","Cong");
    Student student3 = new Student("FA1","Khoa");
    Student student4 = new Student("FA3","Linh");
    Student student5 = new Student("FA2","Khoa");
    listStudent.add(student1);
    listStudent.add(student2);
    listStudent.add(student3);
    
    setStudent.addAll(listStudent); // you can use method addAll() to add an other collection.
    setStudent.add(student4); 
    
    System.out.println("All student:");
    display(setStudent);
    
    /* remove an element.
     *  set only support remove element by object.
     *  It base on compare object use both method hashCode() & equal()
     */
    System.out.println("All student after remove an element:");
    setStudent.remove(student5); 
    display(setStudent);
    
  }
  /**
   * This method to display each element of set.
   * @param setStudent
   */
  public static void display(Set<Student> setStudent) {
    Iterator<Student> iteratorStudent = setStudent.iterator();
    while (iteratorStudent.hasNext()) {
      Student student = (Student) iteratorStudent.next();
      System.out.println(student.toString());
    }
  }
}
