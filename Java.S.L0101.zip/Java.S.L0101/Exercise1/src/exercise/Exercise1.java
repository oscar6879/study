package exercise;

/**
 * @author DieuNT1
 *
 */
public class Exercise1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int number1 = 125;
		int number2 = 2019;

		System.out.println("Sum: " + (number1 + number2));
	}
}
