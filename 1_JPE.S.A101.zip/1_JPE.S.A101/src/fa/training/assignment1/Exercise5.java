package fa.training.assignment1;

import java.util.Scanner;

public class Exercise5 {
	/*
	 * Write a Java program, called CircleExercise to enter radius of a circle and print the area, perimeter of this circle.
	Test Data:
	Radius = 7.5 
	Expected Output
	Perimeter is = 47.12388980384689 
	Area is = 176.71458676442586
	
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double r = 0;
		
		System.out.println("Radius = ");
		r = sc.nextDouble();
		
		System.out.println("Perimeter is = " + (2*r*Math.PI));
		
		System.out.println("Area is = " + (r*r*Math.PI));
		
		sc.close();
	}
}
