package fa.training.assignment1;

public class Exercise2 {

	/*
	 * Print the sum (addition), multiply, subtract, divide and remainder of two numbers.
	Test Data:
	Input first number: 125
	Input second number: 24
	Expected Output:
	125 + 24 = 149
	125 - 24 = 101
	125 x 24 = 3000
	125 / 24 = 5
	125 % 24 = 5
	 */
	public static void main(String[] args) {
		System.out.println("125 + 24 = " + (125 + 24));
		
		System.out.println("125 - 24 = " + (125 - 24));
		
		System.out.println("125 x 24 = " + (125 * 24));
		
		System.out.println("125 / 24 = " + (125 / 24));
		
		System.out.println("125 % 24 = " + (125 % 24));
	}

}
