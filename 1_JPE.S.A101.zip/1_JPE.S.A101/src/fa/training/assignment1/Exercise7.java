package fa.training.assignment1;

import java.util.Scanner;

public class Exercise7 {
	/*
	 * Write a Java program, called LogicalExercise to compare two numbers.
	Input Data:
	Input first integer: 25
	Input second integer: 39
	Expected Output:
	25 != 39                                                                          
	25 < 39                                                                           
	25 <= 39
	 */

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int first, second;

		System.out.print("Input first integer: ");
		first = sc.nextInt();

		System.out.print("Input second integer: ");
		second = sc.nextInt();

		if (first == second) {
			System.out.println(first + " = " + second);
		} else {
			System.out.println(first + " != " + second);
			if (first < second) {
				System.out.println(first + " < " + second);
				System.out.println(first + " <= " + second);
			} else {
				System.out.println(second + " < " + first);
				System.out.println(second + " <= " + first);
			}

		}
		sc.close();
	}
}
