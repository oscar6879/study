package fa.training.assignment1;

import java.util.Scanner;

public class Exercise6 {
	/*
	 * Write a Java program, called RectangleExercise to enter the width and height of a rectangle and  print the area and perimeter of this rectangle.
	Test Data:
	Width = 5.6 Height = 8.5
	Expected Output:
	Area is 5.6 * 8.5 = 47.60
	Perimeter is 2 * (5.6 + 8.5) = 28.20
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double h,w;
		System.out.print("Width = ");
		w = sc.nextDouble();
		
		System.out.print("Height = ");
		h = sc.nextDouble();
		
		System.out.printf("Area is %.1f * %.1f = %.2f \n", w, h, w*h);
		
		System.out.printf("Perimeter is 2 * (%.1f + %.1f) = %.2f \n",w, h, 2*(w+h));
		
		sc.close();
	}
}
