package fa.training.dao;

public class EmployeeImp implements EmployeeDAO{

}
