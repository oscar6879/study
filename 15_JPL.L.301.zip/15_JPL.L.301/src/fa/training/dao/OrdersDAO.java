package fa.training.dao;

import java.util.List;

import fa.training.entities.Orders;

public interface OrdersDAO {
	public List<Orders> getAllOrdersByCustomerId(int customerId);
	
	public boolean addOrder(Orders order);
	
	public boolean updateOrderTotal(int orderId);
}
