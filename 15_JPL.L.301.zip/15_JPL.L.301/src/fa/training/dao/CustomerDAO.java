package fa.training.dao;

import java.sql.SQLException;
import java.util.List;

import fa.training.entities.Customer;

public interface CustomerDAO {
	public List<Customer> getAllCustomer() throws SQLException; 
	
	public boolean addCustomer(Customer customer) throws SQLException;
	
	public boolean deleteCustomer(int customerId) throws SQLException;
	
	public boolean updateCustomer(Customer customer) throws SQLException;
}
