package fa.training.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Connection.Connect;
import fa.training.entities.Customer;
import fa.training.util.CallSQL;

public class CustomerImp implements CustomerDAO{
	static Connection connection = null;
	
	@Override
	public List<Customer> getAllCustomer() {
		List<Customer> list = new ArrayList<Customer>();		
		Statement stt = null;
		try {    	
			connection = Connect.getConnectionDB();
			stt = connection.createStatement();
			ResultSet rs = stt.executeQuery(CallSQL.SQL_GET_ALL_CUSTOMER);
			while(rs.next()) {
				Customer c = new Customer();
				c.setCustomerId(rs.getInt(1));
				c.setCustomerName(rs.getString(2));
				list.add(c);
			}			
		} catch (Exception e) {
			System.out.println("nothing here");
		}finally {
			Connect.closeConnectionDB(connection);
		}
		return list;
	}

	@Override
	public boolean addCustomer(Customer customer) {
		CallableStatement cstt = null;	
		connection = null;		
		try {
			connection = Connect.getConnectionDB();
			cstt = connection.prepareCall(CallSQL.SQL_ADD_CUSTOMER);			
			cstt.setString(1, customer.getCustomerName());
			cstt.execute();		
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Connect.closeConnectionDB(connection);
		}		
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		CallableStatement cstt = null;				
		try {
			connection = Connect.getConnectionDB();
			cstt = connection.prepareCall(CallSQL.SQL_DELETE_CUSTOMER);
			cstt.setInt(1, customerId);			
			cstt.executeUpdate();			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Connect.closeConnectionDB(connection);
		}		
		return false;		
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		CallableStatement cstt = null;			
		try {
			connection = Connect.getConnectionDB();
			cstt = connection.prepareCall(CallSQL.SQL_UPDATE_CUSTOMER);
			cstt.setInt(1, customer.getCustomerId());
			cstt.setString(2, customer.getCustomerName());
			cstt.execute();			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Connect.closeConnectionDB(connection);
		}		
		return false;
	}

}
