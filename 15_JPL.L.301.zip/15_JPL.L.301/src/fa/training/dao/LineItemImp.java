package fa.training.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import Connection.Connect;
import fa.training.entities.LineItem;
import fa.training.util.CallSQL;

public class LineItemImp implements LineItemDAO{
	static Connection connection = null;	
	@Override
	public List<LineItem> getAllItemsByOrderId(int orderId) {
		List<LineItem> list = new ArrayList<LineItem>();	
		Statement stt = null;		
		try {    	
			connection = Connect.getConnectionDB();
			stt = connection.createStatement();
			ResultSet rs = stt.executeQuery(CallSQL.SQL_GET_ALL_ITEMS_BY_ORDERID+orderId);
			while(rs.next()) {
				LineItem l = new LineItem();
				l.setOrderId(rs.getInt(1));
				l.setProductId(rs.getInt(2));
				l.setQuantity(rs.getInt(3));
				l.setPrice(rs.getDouble(4));
				list.add(l);				
			}			
		} catch (Exception e) {
			System.out.println("nothing here");
		}finally {
			Connect.closeConnectionDB(connection);
		}
		return list;		
	}

	@Override
	public boolean addLineItem(LineItem item) {
		CallableStatement cstt;
		try {
			connection = Connect.getConnectionDB();
			cstt = connection.prepareCall(CallSQL.SQL_ADD_LINEITEM);
			cstt.setInt(1, item.getOrderId());
			cstt.setInt(2, item.getProductId());
			cstt.setInt(3, item.getQuantity());
			cstt.setDouble(4, item.getPrice());
			cstt.execute();		
		} catch (Exception e) {
			System.out.println("nothing here");
		} finally {
			Connect.closeConnectionDB(connection);
		}
		return false;
	}

	@Override
	public Double computeOrderTotal(int orderId) {		
		CallableStatement cstt = null;	
		double total = 0;
		try {    	
			connection = Connect.getConnectionDB();
			cstt = connection.prepareCall(CallSQL.SQL_COMPUTE_ORDER_TOTAL);
			cstt.registerOutParameter(1, Types.DOUBLE);
			cstt.setInt(2, orderId);	
			cstt.execute();
			total += cstt.getDouble(1);			
			return total;		
		} catch (Exception e) {
			System.out.println("nothing here");
		}finally {
			Connect.closeConnectionDB(connection);
		}
		return total;
	}

}
