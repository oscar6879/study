package fa.training.dao;

public interface ProductDAO {

}
