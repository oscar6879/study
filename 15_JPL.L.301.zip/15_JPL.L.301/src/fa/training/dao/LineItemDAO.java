package fa.training.dao;

import java.util.List;

import fa.training.entities.LineItem;

public interface LineItemDAO {
	public List<LineItem> getAllItemsByOrderId(int orderId);
	
	public boolean addLineItem(LineItem item);
	
	public Double computeOrderTotal(int orderId);
}
