package fa.training.dao;

public class ProductImp implements ProductDAO{

}
