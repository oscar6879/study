package fa.training.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Connection.Connect;
import fa.training.entities.Orders;
import fa.training.util.CallSQL;

public class OrdersImp implements OrdersDAO{
	static Connection connection = null;	
	@Override
	public List<Orders> getAllOrdersByCustomerId(int customerId) {
		List<Orders> list = new ArrayList<Orders>();		
		Statement stt = null;
		try {    	
			connection = Connect.getConnectionDB();
			stt = connection.createStatement();
			ResultSet rs = stt.executeQuery(CallSQL.SQL_GET_ALL_ORDERS_BY_CUSTOMERID+customerId);
			while(rs.next()) {
				Orders o = new Orders();
				o.setOrderId(rs.getInt(1));
				o.setOrderDate(rs.getDate(2));
				o.setCustomerId(rs.getInt(3));
				o.setEmployeeId(rs.getInt(4));
				o.setTotal(rs.getDouble(5));
				list.add(o);
			}			
		} catch (Exception e) {
			System.out.println("nothing here");
		}finally {
			Connect.closeConnectionDB(connection);
		}
		return list;		
	}

	@Override
	public boolean addOrder(Orders order) {
		CallableStatement cstt = null;	
		connection = null;		
		try {
			connection = Connect.getConnectionDB();
			cstt = connection.prepareCall(CallSQL.SQL_ADD_ORDER);			
			cstt.setDate(1, order.getOrderDate());
			cstt.setInt(2, order.getCustomerId());
			cstt.setInt(3, order.getEmployeeId());
			cstt.setDouble(4, order.getTotal());
			cstt.execute();			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Connect.closeConnectionDB(connection);
		}		
		return false;
	}

	@Override
	public boolean updateOrderTotal(int orderId) {
		CallableStatement cstt = null;			
		connection = null;
			
		try {
			connection = Connect.getConnectionDB();
			cstt = connection.prepareCall(CallSQL.SQL_UPDATE_ORDERS_TOTAL);
			cstt.setInt(1, orderId);
			cstt.execute();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			Connect.closeConnectionDB(connection);
		}
		return false;
	}

}
