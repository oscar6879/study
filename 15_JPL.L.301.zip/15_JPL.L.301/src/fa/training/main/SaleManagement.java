package fa.training.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.dao.CustomerImp;
import fa.training.dao.LineItemImp;
import fa.training.dao.OrdersImp;
import fa.training.entities.Customer;
import fa.training.entities.LineItem;
import fa.training.entities.Orders;
import fa.training.util.Validator;

public class SaleManagement {
	static Scanner sc = new Scanner(System.in);
	static List<Customer> listC = new ArrayList<Customer>();
	static List<Orders> listO = new ArrayList<Orders>();
	static List<LineItem> listL = new ArrayList<LineItem>();	
	static LineItemImp lip = new LineItemImp();
	static CustomerImp cimp = new CustomerImp();
	static OrdersImp oimp = new OrdersImp();
	public static void main(String[] args) {		
		int key;
		
		do {
			System.out.println("1. Get all customer");
			System.out.println("2. Get all orders by customer ID");
			System.out.println("3. Get all item by Orders ID");
			System.out.println("4. Compute order total");
			System.out.println("5. Add customer");
			System.out.println("6. Delete customer");
			System.out.println("7. Update customer");
			System.out.println("8. Add Order");
			System.out.println("9. Add line item");
			System.out.println("10. Update Order total");
			System.out.println("0. Exit");
			System.out.println("=====================================");
			System.out.print("Input function: ");
			key = sc.nextInt(); //Chi nhan so con <enter> chua nhan
			sc.nextLine(); //bypass tu ku <Enter>
			switch (key) {
			case 1:				
				listC = cimp.getAllCustomer();
				for (Customer c : listC) {
					System.out.println(c.toString());
				}
				break;
			case 2:				
				int cus_id_1 = 0;
				do {	
					System.out.print("Input customer ID: ");
					cus_id_1 = Integer.parseInt(sc.next());									
				} while (!Validator.digit(cus_id_1));				
				
				listO = oimp.getAllOrdersByCustomerId(cus_id_1);
				for (Orders o : listO) {
					System.out.println(o.toString());
				}
				break;
			case 3:				
				int ord_id_1 = 0;
				do {
					System.out.print("Input Order ID: ");
					ord_id_1 = Integer.parseInt(sc.next());
				} while (!Validator.digit(ord_id_1));
				listL = lip.getAllItemsByOrderId(ord_id_1);
				for (LineItem l : listL) {
					System.out.println(l.toString());
				}
				break;
			case 4:				
				int ord_id_2 = 0;
				do {
					System.out.print("Input Order ID: ");
					ord_id_2 = Integer.parseInt(sc.next());
					System.out.println("OrderID = "+ord_id_2+" total = "+lip.computeOrderTotal(ord_id_2));
				} while (!Validator.digit(ord_id_2));
				break;
			case 5:				
				Customer c = new Customer();
				System.out.print("Input customer's name: ");
				String name = sc.nextLine();
				c.setCustomerName(name);
				cimp.addCustomer(c);
				break;
			case 6:
				System.out.print("Input customer's id : ");
				int cus_id_2 = sc.nextInt();
				sc.nextLine();
				cimp.deleteCustomer(cus_id_2);
				break;
			case 7:
				System.out.print("Input customer's id : ");
				int cus_id_3 = sc.nextInt();
				sc.nextLine();
				System.out.print("Input name: ");
				String nameEdited = sc.nextLine();
				for (Customer c1 : cimp.getAllCustomer()) {
					if(c1.getCustomerId() == cus_id_3) {
						c1.setCustomerId(cus_id_3);
						c1.setCustomerName(nameEdited);
						cimp.updateCustomer(c1);
						break;
					}
				}				
				break;
			case 8:
				System.out.print("Input date order: ");
				String date1 = sc.nextLine();				
				System.out.print("Input customer id: ");
				int cusid = sc.nextInt();sc.nextLine();
				System.out.print("Input employee id: ");
				int empid = sc.nextInt();sc.nextLine();
				System.out.print("Input total: ");
				double total = sc.nextDouble();sc.nextLine();
				Orders o = new Orders();
				java.sql.Date sDate = new java.sql.Date(Validator.stringToDate(date1).getTime());
				o.setOrderDate(sDate);
				o.setCustomerId(cusid);
				o.setEmployeeId(empid);
				o.setTotal(total);
				oimp.addOrder(o);
				break;
			case 9:
				System.out.print("Input Order ID: ");
				int ordid = sc.nextInt(); sc.nextLine();
				System.out.print("Input Product ID: ");
				int proid = sc.nextInt(); sc.nextLine();
				System.out.print("Input Quantity: ");
				int qtt = sc.nextInt(); sc.nextLine();
				System.out.print("Input price: ");
				double pri = sc.nextDouble();
				LineItem l1 = new LineItem();
				l1.setOrderId(ordid);
				l1.setProductId(proid);
				l1.setQuantity(qtt);
				l1.setPrice(pri);
				lip.addLineItem(l1);
				break;
			case 10:
				System.out.print("Input Order ID: ");
				int ord_id_3 = sc.nextInt();
				sc.nextLine();
				oimp.updateOrderTotal(ord_id_3);				
				break;
			
			default:
				break;
			}
		} while (key != 0);
	}
}
