package fa.training.util;

public class CallSQL {
	//Customer
	public static final String SQL_GET_ALL_CUSTOMER = "SELECT * FROM CUSTOMER";
	public static final String SQL_ADD_CUSTOMER = "{call proc_addCustomer(?)}";
	public static final String SQL_DELETE_CUSTOMER = "{call proc_deleteCustomer(?)}";
	public static final String SQL_UPDATE_CUSTOMER = "{call proc_updateCustomer(?,?)}";
	
	
	//Orders
	public static final String SQL_GET_ALL_ORDERS_BY_CUSTOMERID = "SELECT * FROM ORDERS WHERE customerId = ";
	public static final String SQL_ADD_ORDER = "{call proc_addOrder(?,?,?,?)}";
	public static final String SQL_UPDATE_ORDERS_TOTAL = "{call proc_updateOrderTotal(?)}";
	
	//LineItem
	public static final String SQL_GET_ALL_ITEMS_BY_ORDERID = "SELECT l.* FROM LINEITEM l JOIN PRODUCT p ON l.productId = p.productId WHERE l.orderId =";
	public static final String SQL_COMPUTE_ORDER_TOTAL = "{? = call func_computeOrderTotal(?)}";
	public static final String SQL_ADD_LINEITEM = "{call  proc_AddLineItem(?,?,?,?)}";
}
