package fa.training.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Validator {
	public static boolean digit(int number) {		
		String regex = "\\d+";
		return String.valueOf(number).matches(regex);		
	}
	
	public static String dateToString(Date date) {		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");		
		return sdf.format(date);		
	}	
	
	public static Date stringToDate(String s) {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date date = null;
		try {
			date = df.parse(s);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
