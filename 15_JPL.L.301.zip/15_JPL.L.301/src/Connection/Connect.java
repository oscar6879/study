package Connection;



import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Scanner;

import fa.training.util.CallSQL;
import fa.training.util.Validator;



public class Connect {

	private static String db_url = "jdbc:sqlserver://localhost:1433;databaseName=SMS;";
	private static String user = "sa";
	private static String pass = "fadn@2020";   

	public static Connection getConnectionDB(){
		Connection connection = null;

		try {        	
			//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(db_url, user, pass);            
		} catch (SQLException e) {
			System.out.println("Error");
			e.printStackTrace();
		}
		return connection;
	}
	
	public static void closeConnectionDB(Connection connection) {
		try {
			if(!connection.isClosed() || connection != null) {
				connection.close();
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Input date order: ");
		String date1 = sc.nextLine();
		java.util.Date sDate = (Date) Validator.stringToDate(date1);
		System.out.println(sDate);		

	}
	
}
