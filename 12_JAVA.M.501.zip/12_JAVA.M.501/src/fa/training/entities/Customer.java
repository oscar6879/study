package fa.training.entities;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.utils.Validator;

public class Customer {
	private String name, phone, address;
	private List<Order> listOrder;
	public Customer() {
		super();
	}
	
	public Customer(String name, String phone, String address, List<Order> listOrder) {
		super();
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.listOrder = listOrder;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public List<Order> getListOrder() {
		return listOrder;
	}

	public void setListOrder(List<Order> listOrder) {
		this.listOrder = listOrder;
	}

	public void inputCustomer() {
		Scanner sc = new Scanner(System.in);
		Validator valid = new Validator();
		
		System.out.print("Input name: ");
		this.name = sc.nextLine();
		
		do {
			System.out.print("Input phone: ");
			this.phone = sc.nextLine();
		} while (!valid.validPhone(phone));
		
		System.out.print("Input address: ");
		this.address = sc.nextLine();
		String key;
		this.listOrder = new ArrayList<Order>();
		while (true) {
			Order o = new Order();
			System.out.println("Input order info: ");
			o.inputDetailOrder();			
			this.listOrder.add(o);
			System.out.print("End of the list order? Y/N: ");
			key = sc.next();
			if(key.equals("y") || key.equals("Y")) break;
		}		
	}
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", phone=" + phone + ", address=" + address + ", listOrder=" + listOrder.toString()
				+ "]";
	}

	public static void main(String[] args) {
		Customer c = new Customer();
		c.inputCustomer();
		System.out.println(c.toString());
	}
}
