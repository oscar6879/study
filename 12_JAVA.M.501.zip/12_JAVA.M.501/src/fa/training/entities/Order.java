package fa.training.entities;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import fa.training.utils.Validator;

public class Order {
	private String number;
	private Date date;
	
	
	public Order(String number, Date date) {
		super();
		this.number = number;
		this.date = date;
	}
	public Order() {
		super();
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String dateToString(Date date) {		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");		
		return sdf.format(date);		
	}	
	
	public Date stringToDate(String s) {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date date = null;
		try {
			date = df.parse(s);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	public void inputDetailOrder() {
		Scanner sc = new Scanner(System.in);	
		Validator valid = new Validator();	
		String datevalid;
		do {		
			System.out.print("+ number: ");
			this.number = sc.nextLine();
		} while (!valid.validOrder(number));
		
		do {			
			System.out.print("+ date: ");	
			datevalid = sc.next();				
			this.date = stringToDate(datevalid);						
		} while (!valid.validDate(datevalid));		
	}
	@Override 	
	public String toString() {
		return "Order [number=" + number + ", date=" + dateToString(date) + "]";
	}	
	
}
