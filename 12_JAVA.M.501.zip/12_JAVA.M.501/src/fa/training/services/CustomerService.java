package fa.training.services;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.entities.Customer;

public class CustomerService {
	
	static Scanner sc = new Scanner(System.in);
	
	public List<Customer> createCustomer(){
		List<Customer> list = new ArrayList<Customer>();
		String key;		
		do {
			Customer cus = new Customer();			
			cus.inputCustomer();
			list.add(cus);
			System.out.print("Stop input Customer? Y/N : ");
			key = sc.next();
			if(key.equals("y")||key.equals("Y")) break;
		} while (true);
		return list;	
	}
	
	public void displayAll(List<Customer> list) {			
		for (Customer customer : list) {
			System.out.println(customer.toString());
		}
	}
	
	public void searchCustomer(List<Customer> list){	
		System.out.println("Input phone to search: ");
		String phone = sc.next();		
		boolean check = false;
		for (Customer customer : list) {
			if(customer.getPhone().equals(phone)) {
				System.out.println(customer.toString());	
				check = true;
			}
		}
		if(!check) System.err.println("---Khong co customer nay---");
	}	
	
	public void removeCustomer(List<Customer> list){	
		System.out.println("Input phone of customer: ");
		String phone = sc.next();
		list.removeIf(customer -> customer.getPhone().equalsIgnoreCase(phone));		
	}	
	
	public void saveToFile(List<Customer> list) {
		
			File file = new File("D:\\Duydn11\\JPE\\eclipse_workspace\\M.A.501(901)\\901.txt");
			
				FileWriter fw;
				try {
					fw = new FileWriter(file);
					for (Customer customer : list) {
						fw.write(customer.toString()+"\n");
					}
					fw.close();	
				} catch (IOException e) {					
					e.printStackTrace();
				}						
		
	}
	
	public void displayTable(List<Customer> list) {
		System.err.println("Customer"+"\t\tPhone"+"\t\tAddress"+"\t\tList Order");
		for (Customer customer : list) {
			System.out.println(customer.getName()+"\t\t"+customer.getPhone()+"\t\t"+customer.getAddress()+"\t\t"+customer.getListOrder());
		}
	}
}
