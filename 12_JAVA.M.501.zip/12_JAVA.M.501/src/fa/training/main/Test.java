package fa.training.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.entities.Customer;
import fa.training.services.CustomerService;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int key;
		CustomerService cs = new CustomerService();
		List<Customer> listCustomer = new ArrayList<Customer>();		
		do {
			System.out.println("1. Create customers");
			System.out.println("2. Show all customers");
			System.out.println("3. Search customers");
			System.out.println("4. Remove customers");
			System.out.println("5. Save to file");
			System.out.println("6. Display customers");
			System.out.println("0. Exit");
			System.out.print("Input number: ");
			key =sc.nextInt();
			switch (key) {
			case 1:
				listCustomer = cs.createCustomer();
				break;
			case 2:
				if(listCustomer.isEmpty()) {
					System.err.println("-----Empty list!!!-----");
				}else {
					cs.displayAll(listCustomer);
				}				
				break;
			case 3:
				if(listCustomer.isEmpty()) {
					System.err.println("-----Empty list!!!-----");
				}else {
				cs.searchCustomer(listCustomer);
				}
				break;
			case 4:
				if(listCustomer.isEmpty()) {
					System.err.println("-----Empty list!!!-----");
				}else {
					cs.removeCustomer(listCustomer);
				}
				break;
			case 5:
				if(listCustomer.isEmpty()) {
					System.err.println("-----Empty list!!!-----");
				}else {
					cs.saveToFile(listCustomer);
				}
				break;
			case 6:
				if(listCustomer.isEmpty()) {
					System.err.println("-----Empty list!!!-----");
				}else {
					cs.displayTable(listCustomer);
				}
				break;
			default:
				break;
			}
			if(key == 0) break;
		} while (true);
	}
}
