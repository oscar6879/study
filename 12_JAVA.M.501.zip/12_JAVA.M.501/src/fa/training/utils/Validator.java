package fa.training.utils;


public class Validator {
	public boolean validPhone(String phone) {
		return phone.length()==10 && phone.matches("^[0-9]*$");
	}
	
	public boolean validOrder(String order) {
		return order.length() == 10 & order.matches("^[0-9]*$");
	}
	
	public boolean validDate(String date) {
		return date.matches("^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$");
	}		
}
