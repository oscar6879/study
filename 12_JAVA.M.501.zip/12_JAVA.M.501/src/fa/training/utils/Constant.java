package fa.training.utils;

public class Constant {

}
