package fa.training.exercise2;

import java.util.Scanner;

public class Exercise2 {
	public static void main(String[] args) {
		Integer[] list = {1,5,3,6,4};
		for (Integer maxi : maximum(list)) {
			System.out.println(maxi);
		}

	}

	public static Integer[] maximum(Integer[] list) {
		Integer[] max = new Integer[2];
		max[0] = Integer.max(list[0], list[1]);
		max[1] = Integer.min(list[0], list[1]);
		
		for (Integer numb : list) {
			if (numb > max[0]) {
				max[1] = max[0];
				max[0] = numb;
			} else if (numb < max[0] && numb > max[1]) {
				max[1] = numb;
			}
		}
		return max;
	}
}
