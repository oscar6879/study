package fa.training.exercise1;

import java.util.Arrays;

public class Exercise1 {

    public static Integer[] mergeSort(Integer[] list) {
    	Arrays.sort(list);
    	return list;
    }

    public static void main(String args[]) {
        Integer[] list = { 25, 30, 45, 6, 11, 90, 15 };
        
        System.out.println("Mang ban đau:");
        System.out.println(Arrays.toString(list));
        
        System.out.println("Mang sau khi sap xep:");
        System.out.println(Arrays.toString(mergeSort(list)));  
        
    }
}
