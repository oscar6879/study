package exercise.forloop;

/**
 * Write a program called HarmonicSum to compute the sum of a harmonic series,
 * as shown below, where n=50000. The program shall compute the sum from
 * left-to-right as well as from the right-to-left. Obtain the difference
 * between these two sums and explain the difference.
 * 
 * Harmonic(n) = 1 + 1/2 + 1/3 + ... 1/n
 */

public class HarmonicSum {

  public static void main(String[] args) {

    int n = 50000;
    double sumL2R = printLeftToRightSum(n);
    double sumR2L = printRightToLeftSum(n);
    System.out.printf("Difference: %.15f", (sumL2R - sumR2L));
    System.out.println();
  }

  /**
   * Left-to-right harmonic sum.
   * 
   * @param int n
   */
  private static double printLeftToRightSum(int n) {
    double sum = 0.0;
    for (int i = 1; i <= n; i++) {
      sum += (double) 1 / i;
    }
    System.out.printf("Left-to-right harmonic sum %.15f", sum);
    System.out.println();

    return sum;
  }

  /**
   * Right-to-left harmonic sum.
   * @param n
   * @return
   */
  private static double printRightToLeftSum(int n) {
    double sum = 0.0;
    for (int i = n; i >= 1; i--) {
      sum += (double) 1 / i;
    }
    System.out.printf("Right-to-left harmonic sum %.15f", sum);
    System.out.println();

    return sum;
  }
}
