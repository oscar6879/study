/**
 * 
 */
/**
 * @author DieuNT1
 *
 */
package exercise.forloop;