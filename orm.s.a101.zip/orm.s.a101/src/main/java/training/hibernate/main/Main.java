package training.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import training.hibernate.model.Employee;
import training.hibernate.utils.HibernateUtils;

public class Main {
	public static void main(String[] args) {
		SessionFactory sessionFactory = HibernateUtils.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		Employee emp1 = new Employee(1,"Nhan1","Phan1");
		Employee emp2 = new Employee(2,"Nhan2","Phan2");
		Employee emp3 = new Employee(3,"Nhan3","Phan3");
		
		session.save(emp1);
		session.save(emp2);
		session.save(emp3);
		
		transaction.commit();
	}
	
}
