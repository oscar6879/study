package fa.training.services;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import fa.training.utils.Constant;

public class DepartmentService {

/**
 *  This method to save a list of department into file.
 *  
 * @param listDepartment
 * @param append, true if write append file, otherwise write replace.
 * @return 
 * @throws Exception
 */
  public String save(List<String> listDepartment, boolean append) throws Exception {
    try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(Constant.FILE_PATH, append));) {
      for (String department : listDepartment) {
        bufferedWriter.write(department + "\n");
        // we are use pass by object but we save with String.
      }
      bufferedWriter.flush();
    }
    return Constant.SUCCESS;
  }

  /**
   * This method to get all department in file.
   * 
   * @throws Exception
   */
  public List<String> findAll() throws Exception {
    File f = new File(Constant.FILE_PATH);
    if (!f.exists() && !f.canRead()) {
      return null;
    }

    List<String> listDepartmenInfo = new ArrayList<>();
    try (BufferedReader bufferedReader = new BufferedReader(new FileReader(
        Constant.FILE_PATH))) {
      while (bufferedReader.read() != -1) {
        // if file has more character we will get each line.
        listDepartmenInfo.add(bufferedReader.readLine());
      }
    }

    return listDepartmenInfo;
  }

  /**
   * The method to remove a specific department.
   * 
   * @param id
   *          of department.
   * @return success if an existed department removed, otherwise returns false.
   * @throws Exception
   */
  public String remove(String id) throws Exception {

    List<String> deStrings = findAll();
    
    // Write file if 'deStrings' is not null  
    if (deStrings != null) {
      Iterator<String> iterator = deStrings.iterator();
      boolean removed = false;
      while (iterator.hasNext()) {
        String department = (String) iterator.next();
        if (department.contains("deptNo=" + id)) {
          iterator.remove();
          removed = true;
          break;
        }
      }
      if (removed) {
        save(deStrings, false);
        return Constant.SUCCESS;
      }
      return Constant.FAIL;
    }
    return Constant.FAIL;
  }

}
