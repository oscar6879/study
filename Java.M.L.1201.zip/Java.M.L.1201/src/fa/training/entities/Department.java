package fa.training.entities;

import java.io.Serializable;

public class Department implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  private String deptNo;
  private String deptName;
  private String location;

  public Department(String deptNo, String deptName, String location) {
    super();
    this.deptNo = deptNo;
    this.deptName = deptName;
    this.location = location;
  }

  public Department() {
    super();
  }

  public String getDeptNo() {
    return deptNo;
  }

  public void setDeptNo(String deptNo) {
    this.deptNo = deptNo;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getDeptName() {
    return deptName;
  }

  public void setDeptName(String deptName) {
    this.deptName = deptName;
  }

  @Override
  public String toString() {
    return "Department [deptNo=" + deptNo + ", deptName=" + deptName
        + ", location=" + location + "]";
  }

}
