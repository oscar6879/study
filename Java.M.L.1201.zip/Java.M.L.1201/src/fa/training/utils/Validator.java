package fa.training.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * An utility class provides the functions to check input data.
 * 
 * @author DieuNT1
 *
 */
public class Validator {
  private static final String DEPT_ID_REGEX = "^[DP]+\\d{3,3}";

  /**
   * Check department id is valid.
   * 
   * @param department
   *          id.
   * @return true, if valid, otherwise return false.
   */
  public static boolean isDeptId(String deptId) {
    Pattern pattern = Pattern.compile(DEPT_ID_REGEX);
    Matcher matcher = pattern.matcher(deptId);

    return matcher.matches();
  }
}
