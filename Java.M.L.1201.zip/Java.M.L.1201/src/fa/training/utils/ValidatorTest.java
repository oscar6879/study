package fa.training.utils;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidatorTest {

  @Test
  public void testIsDeptId() {
    String deptId = "DP001";

    assertTrue(Validator.isDeptId(deptId));
  }

  @Test
  public void testIsDeptId2() {
    String deptId = "DP01";

    assertFalse(Validator.isDeptId(deptId));
  }

}
