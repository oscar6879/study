package fa.training.utils;

public class Constant {
  public static final String FILE_PATH = "department.dat";
  public static final String SUCCESS = "success";
  public static final String FAIL = "fail";
  public static final String EMPTY = "File is Empty";
  
}
