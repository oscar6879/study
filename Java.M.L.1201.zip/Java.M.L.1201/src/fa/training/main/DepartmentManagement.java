package fa.training.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fa.training.entities.Department;
import fa.training.services.DepartmentService;
import fa.training.utils.Validator;

public class DepartmentManagement {

  /**
   * This method to display menu.
   */
  private static void menu() {
    System.out.println("Choose function:");
    System.out.println("1. Create and save department.");
    System.out.println("2. Show all info.");
    System.out.println("3. Remove a department.");
    System.out.println("4. Exit.");
    System.out.print("Your choice:");
  }

  /**
   * the main method.
   * 
   * @param args
   * @return
   */
  public static void main(String[] args) {
    DepartmentService departmentService = new DepartmentService();
    Scanner scanner = new Scanner(System.in);
    int option = 0;

    do {
      menu();
      option = Integer.parseInt(scanner.nextLine());
      switch (option) {
        case 1:
          try {
            List<String> listDepartment = createDepartment(scanner);

            departmentService.save(listDepartment, true);

          } catch (Exception e) {
            e.printStackTrace();
          }

          break;
        case 2:

          try {
            List<String> deStrings = departmentService.findAll();
            display(deStrings);

          } catch (Exception e) {
            e.printStackTrace();
          }
          break;
        case 3:
          System.out.println("Enter department id:");
          String deptId = scanner.nextLine();

          try {
            System.out
                .println("Removed: " + departmentService.remove(deptId));

          } catch (Exception e) {
            e.printStackTrace();
          }
          break;

      }
    } while (option < 4);

    scanner.close();
  }

  /**
   * This method to input a department.
   * 
   * @param scanner
   * @return department object.
   */
  private static List<String> createDepartment(Scanner scanner) {
    List<String> departments = new ArrayList<String>();
    char loop;
    Department department = null;
    boolean invalid;
    do {
      String deptNo = null;
      do {
        invalid = false;
        System.out.println("Enter Department number (start with 'DP' + 3 digits):");
        deptNo = scanner.nextLine();
        if (!Validator.isDeptId(deptNo)) {
          invalid = true;
        }
      } while (invalid);

      System.out.println("Enter Department name:");
      String deptName = scanner.nextLine();

      System.out.println("Enter Department location:");
      String location = scanner.nextLine();

      department = new Department(deptNo, deptName, location);
      departments.add(department.toString());

      System.out.println("Do you want continute (y/Y)?");
      loop = scanner.nextLine().charAt(0);

    } while ((loop == 'y') || (loop == 'Y'));
    return departments;
  }

  /**
   * to display each department from file.
   * 
   * @param departmentService
   */
  private static void display(List<String> listDepartment) {
    if (listDepartment != null) {
      for (String department : listDepartment) {
        System.out.println(department);
      }
    } else {
      System.out.println("No data!");
    }

  }

}
