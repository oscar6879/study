package fa.training.main;

import fa.training.entities.SavingsAccount;

public class SavingsAccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double rate = 0.04;
		SavingsAccount saver1 = new SavingsAccount(rate, 2000); 
		SavingsAccount saver2 = new SavingsAccount(rate, 3000);
		
		System.out.printf("$%.2f\n",saver1.calculateMonthlyInterest());
		System.out.printf("$%.2f\n",saver2.calculateMonthlyInterest());
		System.out.println("-------------NEW----------------");
		double newRate = 0.05;
		saver1.setAnnualInterestRate(newRate);
		saver2.setAnnualInterestRate(newRate);
		
		System.out.printf("$%.2f\n",saver1.calculateMonthlyInterest());
		System.out.printf("$%.2f",saver2.calculateMonthlyInterest());
	}

}
