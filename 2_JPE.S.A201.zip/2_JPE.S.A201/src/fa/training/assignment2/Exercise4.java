package fa.training.assignment2;

import java.util.Scanner;

public class Exercise4 {
	/*
	 *	Write a Java programs, called CylinderComputation to print the surface area, base area, and volume of a cylinder,
	 *  given its radius and height (in doubles). 
		You should use 5 double variables called radius, height, surfaceArea, baseArea and volume.
		Take note that space (blank) is not allowed in variable names. 
		
		Output

			Surface area = 1295.906968125
			
			Base area = 490.8738515625
			
			Volume = 1963.49540625
	 */

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double r, h, surfaceArea, baseArea, volume;
		
		System.out.println("Input radius: ");
		r = sc.nextDouble();
		
		System.out.println("Input height: ");
		h = sc.nextDouble();
		
		surfaceArea = 2 * r * Math.PI * h + 2 * r * r * Math.PI;
		baseArea = r * r * Math.PI;
		volume = r * r * Math.PI * h;
		
		System.out.println("Surface area = " + surfaceArea);
		System.out.println("Base area = " + baseArea);
		System.out.println("Volume = " + volume);
		
		sc.close();
	}

}
