package fa.training.assignment2;

import java.util.Scanner;

public class Exercise3 {
	/*
	 * Write a Java program to add FIVE integers and display their sum.
	 * 
	 * 	Output

		Input first number: 121
		
		Input second number: 12
		
		Input third number: 123
		
		Input fourth number: 22
		
		Input fourth number: 23
		
		The sum is 301
	 */
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			
			int first , second , third , fourth, fifth ;
			
			System.out.print("Input first number: ");
			first = sc.nextInt();
			
			System.out.print("Input second number: ");
			second= sc.nextInt();
			
			System.out.print("Input third number: ");
			third = sc.nextInt();
			 
			System.out.print("Input fourth number: ");
			fourth = sc.nextInt();
			
			System.out.print("Input fifth number: ");
			fifth = sc.nextInt();
			
			
			System.out.println("The sum is " + (first + second + third + fourth + fifth));
			sc.close();
		}
}
