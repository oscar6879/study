package fa.training.assignment2;


public class Exercise1 {
	/*
	a) (101 + 0) / 3
	b) 3.0e-6 * 10000000.1
	c) true && true
	d) false && true
	e) (false && false) || (true && true)
	f) (false || false) && (true && true)
	
		 */
	public static void main(String[] args) {
		System.out.println("(101 + 0) / 3 --> " + ((101 + 0) / 3));	
		System.out.println("3.0e-6 * 10000000.1  -->  " + (3.0e-6 * 10000000.1));
		System.out.println("true && true  --> " + (true && true));
		System.out.println("false && true --> " + (false && true));
		System.out.println("(false && false) || (true && true) --> " + ((false && false) || (true && true)));
		System.out.println("(false || false) && (true && true) --> " + ((false || false) && (true && true)));
	}

}
