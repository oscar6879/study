package fa.training.assignment2;

import java.util.Scanner;

public class Exercise2 {
	/*
	 * Write a Java program to enter four integer numbers and prints equal if all four are equal, 
	 * and not equal otherwise.
	 * Output                                        

		Input first number: 101
		
		Input second number: 122
		
		Input third number: 123
		
		Input fourth number: 111
		
		Numbers are not equal!
	 */

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int first , second , third , fourth ;
		
		System.out.print("Input first number: ");
		first = sc.nextInt();
		
		System.out.print("Input second number: ");
		second= sc.nextInt();
		
		System.out.print("Input third number: ");
		third = sc.nextInt();
		 
		System.out.print("Input fourth number: ");
		fourth = sc.nextInt();
		
		if(first == second && second == third && third == fourth) {
			System.out.println("Numbers are equal!");
		}else {
			System.out.println("Numbers are not equal!");
		}
		
		sc.close();

	}
}
