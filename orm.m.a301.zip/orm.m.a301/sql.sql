CREATE DATABASE ORM_M_A301;
GO

IF NOT EXISTS ( SELECT * FROM sys.schemas WHERE name = N'training' )
EXEC('CREATE SCHEMA [training]');


