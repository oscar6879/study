package training.dao;

public class InterviewDao extends EntityDao<Object> {

}
