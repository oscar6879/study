package training.dao;

public class EntryTestDao extends EntityDao<Object> {

}
