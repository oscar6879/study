package fa.training.main;

import java.util.Scanner;

import fa.training.entities.Rectangle;

public class ShapeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle[] arrRectangle = input();

		show(arrRectangle);
		
		showAreaMax(arrRectangle);
		
		showPerimeterMin(arrRectangle);
	}

	private static Rectangle[] input() {
		Scanner sc = new Scanner(System.in);
		int n = 0;
		do {
			System.out.print("Enter number of rectangle: ");
			n = Integer.parseInt(sc.nextLine());
		} while (n <= 0);
		Rectangle[] arrRectangle = new Rectangle[n];
		for (int i = 0; i < arrRectangle.length; i++) {
			arrRectangle[i] = new Rectangle();
			System.out.println("--------Rectangle " + (i + 1) + "---------");
			System.out.print("Enter width: ");
			int w = Integer.parseInt(sc.nextLine());
			System.out.print("Enter length: ");
			int l = Integer.parseInt(sc.nextLine());
			arrRectangle[i].setLengthWidth(l, w);
		}
		return arrRectangle;
	}

	private static void show(Rectangle[] arrRectangle) {
		System.out.println("----------INFORMATION----------");
		for (int i = 0; i < arrRectangle.length; i++) {
			System.out.println("--------Rectangle " + (i + 1) + "---------");
			showOne(arrRectangle[i]);
		}
	}

	private static void showOne(Rectangle rectangle) {
		System.out.println("Length: " + rectangle.getLength());
		System.out.println("Width: " + +rectangle.getWidth());
		System.out.println("Perimeter: " + rectangle.calculatePerimeter());
		System.out.println("Area: " + rectangle.calculateArea());
	}

	private static void showAreaMax(Rectangle[] arrRectangle) {
		int max = areaMax(arrRectangle);
		System.out.println("----------AREA MAX----------");
		int j = 1;
		for (int i = 0; i < arrRectangle.length; i++) {
			if (arrRectangle[i].calculateArea() == max) {
				System.out.println("--------Rectangle " + j + "---------");
				showOne(arrRectangle[i]);
				j++;
			}
		}
	}
	
	private static void showPerimeterMin(Rectangle[] arrRectangle) {
		int min = perimeterMin(arrRectangle);
		System.out.println("----------PERIMETER MIN----------");
		int j = 1;
		for (int i = 0; i < arrRectangle.length; i++) {
			if (arrRectangle[i].calculatePerimeter() == min) {
				System.out.println("--------Rectangle " + j + "---------");
				showOne(arrRectangle[i]);
				j++;
			}
		}
	}
	
	private static int perimeterMin(Rectangle[] arrRectangle) {
		int min = arrRectangle[0].calculatePerimeter();
		for (int i = 1; i < arrRectangle.length; i++) {
			if (min > arrRectangle[i].calculatePerimeter())
				min = arrRectangle[i].calculatePerimeter();
		}
		return min;
	}

	private static int areaMax(Rectangle[] arrRectangle) {
		int max = arrRectangle[0].calculateArea();
		for (int i = 1; i < arrRectangle.length; i++) {
			if (max < arrRectangle[i].calculateArea())
				max = arrRectangle[i].calculateArea();
		}
		return max;
	}
}
